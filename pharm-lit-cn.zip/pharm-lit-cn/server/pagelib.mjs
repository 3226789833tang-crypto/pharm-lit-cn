// In-page helper library. This function is serialised with Function.prototype.toString()
// and evaluated inside the CNKI / Wanfang tab, so it must be fully self-contained
// (no imports, no closures over Node-side variables).
export function cnlitPageLib() {
  const L = { v: 3 };
  const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
  const text = (el) => (el ? (el.textContent || '').replace(/\s+/g, ' ').trim() : '');
  const strip = (s) => (s == null ? '' : String(s))
    .replace(/<[^>]+>/g, '')
    .replace(/&nbsp;/g, ' ').replace(/&lt;/g, '<').replace(/&gt;/g, '>')
    .replace(/&quot;/g, '"').replace(/&#39;/g, "'").replace(/&amp;/g, '&')
    .replace(/\s+/g, ' ').trim();

  // ======================================================================
  // CNKI (kns.cnki.net)
  // ======================================================================
  L.cnkiIdentity = async () => {
    let unit = null, user = null;
    for (let i = 0; i < 12; i++) {
      unit = document.querySelector('.ecp_header_unitName, .ecp_unitAccountName');
      user = document.querySelector('.ecp_header_userName, .ecp_header_personName');
      if ((unit && (unit.getAttribute('title') || text(unit))) || (user && text(user))) break;
      await sleep(500);
    }
    return {
      institution: unit ? (unit.getAttribute('title') || text(unit)) : '',
      personal: user ? (user.getAttribute('title') || text(user)) : '',
      url: location.href,
    };
  };

  L.cnkiQJ = (o, from) => {
    const groups = [{
      Key: 'Subject', Title: '', Logic: 0,
      Items: [{ Key: 'Expert', Title: '', Logic: 0, Field: 'EXPERT', Operator: 0, Value: o.expr, Value2: '' }],
      ChildItems: [],
    }];
    if (o.lybsm && o.lybsm.length) {
      groups.push({
        Key: 'SCDBGroup', Title: '', Logic: 0, Items: [],
        ChildItems: [{
          Key: 'LYBSM', Title: '', Logic: 0, ChildItems: [],
          Items: o.lybsm.map((c) => ({ Key: c, Title: '', Logic: 1, Field: 'LYBSM', Operator: 'DEFAULT', Value: c, Value2: '', Name: 'LYBSM', ExtendType: 0 })),
        }],
      });
    }
    return {
      Platform: '', Resource: 'CROSSDB', Classid: 'WD0FTY92', Products: '',
      QNode: { QGroup: groups }, ExScope: '1', SearchType: 4, Rlang: 'CHINESE',
      KuaKuCode: o.kuaku, SearchFrom: from,
    };
  };

  // CNKI only accepts the page sizes offered in its UI (10/20/50); other sizes return “暂无数据”.
  const cnkiSize = (n) => (!n || n <= 10 ? 10 : n <= 20 ? 20 : 50);
  L.cnkiGridPage = async (o, page, turnpage) => {
    const p = {
      boolSearch: page === 1 ? 'true' : 'false',
      QueryJson: JSON.stringify(L.cnkiQJ(o, page === 1 ? 1 : 4)),
      pageNum: String(page), pageSize: String(cnkiSize(o.size)),
      sortField: o.sortField || '', sortType: o.sortType || '',
      dstyle: 'listmode', productStr: '', aside: '', searchFrom: '资源范围：总库',
    };
    if (page === 1) p.CurPage = '1';
    if (turnpage) p.turnpage = turnpage;
    let res;
    try {
      res = await fetch('/kns8s/brief/grid', {
        method: 'POST', body: new URLSearchParams(p), credentials: 'include',
        headers: { 'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8', 'X-Requested-With': 'XMLHttpRequest' },
      });
    } catch (e) { return { error: 'network: ' + e }; }
    const html = await res.text();
    if (!/id="totalCnt"/.test(html)) {
      if (/暂无数据/.test(html)) return { empty: true, total: 0, rows: [] };
      return { verify: true, status: res.status, snippet: strip(html).slice(0, 200) };
    }
    const d = new DOMParser().parseFromString(html, 'text/html');
    const val = (id) => { const e = d.getElementById(id); return e ? (e.value || e.getAttribute('value') || '') : ''; };
    let groupCount = {};
    try { groupCount = JSON.parse(val('hidGroupCount') || '{}'); } catch (e) { /* ignore */ }
    const num = (el) => { const m = text(el).replace(/,/g, '').match(/\d+/); return m ? +m[0] : 0; };
    const rows = [...d.querySelectorAll('table.result-table-list tbody tr')].map((tr) => {
      const a = tr.querySelector('td.name a');
      const col = tr.querySelector('a.icon-collect');
      const authorLinks = [...tr.querySelectorAll('td.author a')].map(text).filter(Boolean);
      const authorText = text(tr.querySelector('td.author'));
      const srcA = tr.querySelector('td.source a');
      return {
        seq: parseInt(text(tr.querySelector('td.seq')), 10) || null,
        title: text(a),
        url: a ? a.getAttribute('href') : '',
        authors: authorLinks.length ? authorLinks : authorText.split(/[;；]/).map((s) => s.trim()).filter(Boolean),
        source: text(tr.querySelector('td.source')),
        sourceUrl: srcA ? srcA.getAttribute('href') : '',
        date: text(tr.querySelector('td.date')),
        dbType: text(tr.querySelector('td.data')),
        cited: num(tr.querySelector('td.quote')),
        downloads: num(tr.querySelector('td.download')),
        dbname: col ? (col.getAttribute('data-dbname') || '') : '',
        filename: col ? (col.getAttribute('data-filename') || '') : '',
        exportId: (tr.querySelector('input.cbItem') || {}).value || '',
      };
    });
    return { total: parseInt(val('totalCnt') || '0', 10) || 0, groupCount, rows, turnpage: val('hidTurnPage') };
  };

  // Fetch up to o.max rows (pages of o.size, max 50), sleeping o.delay ms between pages.
  L.cnkiSearch = async (o) => {
    const size = cnkiSize(o.size || 50);
    const max = Math.max(1, o.max || size);
    const out = { total: 0, groupCount: {}, rows: [], pages: 0 };
    let tp = null;
    for (let page = 1; out.rows.length < max; page++) {
      if (page > 1) await sleep(o.delay || 1200);
      const r = await L.cnkiGridPage({ ...o, size }, page, tp);
      out.pages++;
      if (r.error || r.verify) return { ...out, ...r };
      if (r.empty) { out.empty = true; break; }
      if (page === 1) { out.total = r.total; out.groupCount = r.groupCount; }
      out.rows.push(...r.rows);
      tp = r.turnpage;
      if (!r.rows.length || out.rows.length >= out.total || r.rows.length < size) break;
    }
    out.rows = out.rows.slice(0, max);
    return out;
  };

  L.cnkiExport = async (ids) => {
    let res;
    try {
      res = await fetch('/dm8/API/GetExport', {
        method: 'POST', credentials: 'include',
        body: new URLSearchParams({ filename: ids.join(','), displaymode: 'GBTREFER,elearning,EndNote', uniplatform: 'NZKPT' }),
        headers: { 'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8', 'X-Requested-With': 'XMLHttpRequest' },
      });
    } catch (e) { return { error: 'network: ' + e }; }
    let j;
    try { j = await res.json(); } catch (e) { return { error: 'export: non-JSON response (HTTP ' + res.status + ')' }; }
    if (j.code !== 1) return { error: 'export: ' + (j.msg || 'code ' + j.code) };
    const get = (mode) => ((j.data || []).find((x) => x.mode === mode) || {}).value || [];
    return { gb: get('GBTREFER'), el: get('ELEARNING'), en: get('ENDNOTE') };
  };

  L.cnkiDetail = async (url) => {
    let res;
    try { res = await fetch(url, { credentials: 'include' }); } catch (e) { return { error: 'network: ' + e }; }
    const html = await res.text();
    const d = new DOMParser().parseFromString(html, 'text/html');
    if (!d.querySelector('.wx-tit')) {
      return { error: 'detail page not recognised', verify: /验证|captcha|拼图/i.test(html), snippet: strip(html).slice(0, 160) };
    }
    const fields = {};
    d.querySelectorAll('.rowtit').forEach((t) => {
      const label = text(t).replace(/[：:]\s*$/, '');
      const host = t.parentElement;
      let v = '';
      if (host) v = text(host).replace(text(t), '').trim();
      if (label && v && !fields[label] && !/^(摘要|关键词|视频摘要|观看视频)$/.test(label)) fields[label] = v.slice(0, 600);
    });
    const h3 = [...d.querySelectorAll('.wx-tit h3')];
    const authors = h3[0] ? [...h3[0].querySelectorAll('a, span')].map(text).map((s) => s.replace(/[\d,，\s]+$/, '')).filter(Boolean) : [];
    const orgs = h3[1] ? [...h3[1].querySelectorAll('a, span')].map(text).map((s) => s.replace(/^\d+\.\s*/, '')).filter(Boolean) : [];
    const summary = d.querySelector('#ChDivSummary');
    return {
      title: text(d.querySelector('.wx-tit h1')).replace(/\s*附视频$/, ''),
      authors: [...new Set(authors)],
      orgs: [...new Set(orgs)],
      abstract: summary ? text(summary) : (fields['摘要'] || ''),
      keywords: [...d.querySelectorAll('p.keywords a')].map((a) => text(a).replace(/[;；]$/, '')).filter(Boolean),
      topTip: text(d.querySelector('.top-tip')),
      fields,
    };
  };

  L.cnkiFacets = async (o) => {
    let res;
    try {
      res = await fetch('/kns8s/group/result', {
        method: 'POST', credentials: 'include',
        body: new URLSearchParams({ queryJson: JSON.stringify(L.cnkiQJ(o, 1)) }),
        headers: { 'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8', 'X-Requested-With': 'XMLHttpRequest' },
      });
    } catch (e) { return { error: 'network: ' + e }; }
    const html = await res.text();
    const d = new DOMParser().parseFromString(html, 'text/html');
    const groups = {};
    d.querySelectorAll('dd[field]').forEach((dd) => {
      const items = [...dd.querySelectorAll('li')].map((li) => {
        const inp = li.querySelector('input');
        const cnt = (text(li.querySelector('span')).match(/[\d.]+万?/) || [''])[0];
        return { value: inp ? inp.value : '', label: inp ? (inp.getAttribute('text') || inp.value) : text(li), count: cnt };
      });
      if (items.length) groups[dd.getAttribute('tit') || dd.getAttribute('field')] = items;
    });
    return { groups };
  };

  // ======================================================================
  // Wanfang (d.wanfangdata.com.cn) — gRPC-web + protobuf
  // ======================================================================
  const PB = {
    ev(n) { const o = []; n = BigInt(n); do { let b = Number(n & 0x7fn); n >>= 7n; if (n > 0n) b |= 0x80; o.push(b); } while (n > 0n); return o; },
    str(f, s) { const b = new TextEncoder().encode(String(s)); return [...PB.ev((f << 3) | 2), ...PB.ev(b.length), ...b]; },
    int(f, v) { return [...PB.ev((f << 3) | 0), ...PB.ev(v)]; },
    bytes(f, arr) { return [...PB.ev((f << 3) | 2), ...PB.ev(arr.length), ...arr]; },
    frame(arr) { const l = arr.length; return new Uint8Array([0, (l >>> 24) & 255, (l >>> 16) & 255, (l >>> 8) & 255, l & 255, ...arr]); },
    vi(a, p) { let r = 0, s = 0, b; do { b = a[p++]; r += (b & 0x7f) * Math.pow(2, s); s += 7; } while (b & 0x80); return [r, p]; },
    fields(a) {
      const out = []; let p = 0;
      while (p < a.length) {
        let k; [k, p] = PB.vi(a, p);
        const f = Math.floor(k / 8), w = k % 8;
        if (w === 0) { let v; [v, p] = PB.vi(a, p); out.push({ f, v }); }
        else if (w === 2) { let l; [l, p] = PB.vi(a, p); out.push({ f, raw: a.subarray(p, p + l) }); p += l; }
        else if (w === 5) { p += 4; } else if (w === 1) { p += 8; } else { break; }
      }
      return out;
    },
    frames(a) {
      const fr = []; let p = 0;
      while (p + 5 <= a.length) {
        const len = (a[p + 1] << 24) | (a[p + 2] << 16) | (a[p + 3] << 8) | a[p + 4];
        fr.push({ flag: a[p], data: a.subarray(p + 5, p + 5 + len) }); p += 5 + len;
      }
      return fr;
    },
  };
  const td = new TextDecoder();

  L.wfIdentity = async () => {
    let b = null;
    for (let i = 0; i < 12; i++) { b = document.querySelector('.anxs-8qwe-jgName'); if (b && text(b)) break; await sleep(500); }
    let inst = b ? text(b) : '';
    if (!inst) {
      const lines = document.body.innerText.split('\n').map((s) => s.trim()).filter(Boolean).slice(0, 8);
      const i = lines.findIndex((s) => /登录/.test(s));
      if (i > 0 && !/导航|平台/.test(lines[i - 1])) inst = lines[i - 1];
    }
    return { institution: inst, url: location.href, verifyPage: /\/verify/.test(location.pathname), protoReady: typeof proto !== 'undefined' && !!proto.Periodical };
  };

  async function wfCall(path, msg) {
    const tgt = (document.cookie.split(';').map((s) => s.trim()).find((c) => c.startsWith('CASTGC=')) || '').slice(7);
    let res;
    try {
      res = await fetch(path, {
        method: 'POST', body: PB.frame(msg), credentials: 'include',
        headers: {
          'Content-Type': 'application/grpc-web+proto', 'X-Grpc-Web': '1',
          'X-User-Agent': 'grpc-web-javascript/0.1', Cookies: `CASTGC=${tgt};CASTGCSpecial=;`,
        },
      });
    } catch (e) { return { error: 'network: ' + e }; }
    const buf = new Uint8Array(await res.arrayBuffer());
    const gs = res.headers.get('grpc-status');
    if (res.status !== 200 || (gs && gs !== '0')) {
      let gm = res.headers.get('grpc-message') || '';
      try { gm = decodeURIComponent(gm); } catch (e) { /* keep */ }
      return { error: `HTTP ${res.status} grpc-status ${gs || '-'} ${strip(gm).slice(0, 160)}` };
    }
    const fr = PB.frames(buf);
    const data = fr.find((f) => f.flag === 0);
    const trailer = fr.find((f) => f.flag & 0x80);
    if (trailer) {
      const t = td.decode(trailer.data);
      const m = t.match(/grpc-status:\s*(\d+)/);
      if (m && m[1] !== '0') return { error: 'grpc trailer: ' + t.replace(/\s+/g, ' ').slice(0, 200) };
    }
    return { data: data ? data.data : new Uint8Array(0) };
  }

  const WF_KEEP = ['id', 'titleList', 'creatorList', 'foreigncreatorList', 'originalorganizationList', 'organizationnormList',
    'firstorganizationList', 'keywordsList', 'foreignkeywordsList', 'abstractList', 'citedcount', 'downloadcount',
    'periodicalid', 'periodicaltitleList', 'publishdate', 'publishyear', 'volum', 'issue', 'page', 'pageno', 'doi',
    'issn', 'cn', 'coreperiodicalList', 'fundList', 'originalclasscodeList', 'classcodeList', 'machinedclasscodeList',
    'degree', 'tutorList', 'major', 'meetingtitleList', 'meetingdate', 'meetingarea', 'meetingyear', 'sponsorList',
    'authororgList', 'language', 'sourcedbList', 'columnList', 'publishstatus', 'type', 'hasfulltext', 'isoa'];

  function wfDecodeResource(raw, knownType) {
    const inner = PB.fields(raw);
    const tf = inner.find((y) => y.f === 1 && y.raw);
    const type = tf ? td.decode(tf.raw) : (knownType || '');
    const body = inner.find((y) => y.f >= 100 && y.raw);
    if (!type || !body) return null;
    if (typeof proto === 'undefined' || !proto[type] || !proto[type].deserializeBinary) return { type, error: 'proto class missing for ' + type };
    let o;
    try { o = proto[type].deserializeBinary(body.raw).toObject(); } catch (e) { return { type, error: 'decode: ' + e }; }
    const k = {};
    for (const key of WF_KEEP) {
      const v = o[key];
      if (v === undefined || v === null || v === '' || v === 0 || (Array.isArray(v) && !v.length)) continue;
      k[key] = v;
    }
    return { type, obj: k };
  }

  L.wfSearchPage = async (o) => {
    const common = [...PB.str(1, o.type || 'paper'), ...PB.str(2, o.q)];
    if (o.sortField) common.push(...PB.bytes(3, [...PB.str(1, o.sortField), ...PB.int(2, o.sortOrder == null ? 1 : o.sortOrder)]));
    common.push(...PB.int(5, o.page || 1), ...PB.int(6, o.size || 20), ...PB.bytes(8, [0]), ...PB.int(9, 1), ...PB.str(12, 'pc'), ...PB.str(13, 'search'));
    const r = await wfCall('/SearchService.SearchService/search', [...PB.bytes(1, common), ...PB.int(2, 1)]);
    if (r.error) return r;
    const top = PB.fields(r.data);
    const totalF = top.find((x) => x.f === 3 && x.v !== undefined);
    const items = top.filter((x) => x.f === 4 && x.raw).map((x) => wfDecodeResource(x.raw)).filter(Boolean);
    return { total: totalF ? totalF.v : 0, items };
  };

  L.wfSearch = async (o) => {
    const size = Math.max(1, Math.min(o.size || 50, 50));
    const max = Math.max(1, o.max || size);
    const out = { total: 0, items: [], pages: 0 };
    for (let page = o.startPage || 1; out.items.length < max; page++) {
      if (out.pages) await sleep(o.delay || 600);
      const r = await L.wfSearchPage({ ...o, size, page });
      out.pages++;
      if (r.error) return { ...out, error: r.error };
      if (out.pages === 1) out.total = r.total;
      out.items.push(...r.items);
      if (!r.items.length || r.items.length < size || page * size >= out.total) break;
    }
    out.items = out.items.slice(0, max);
    return out;
  };

  L.wfDetail = async (type, id) => {
    const r = await wfCall('/Detail.DetailService/getDetailInFormation', [...PB.str(1, type), ...PB.str(2, id)]);
    if (r.error) return r;
    const top = PB.fields(r.data);
    const res = top.find((x) => x.f === 1 && x.raw);
    if (!res) return { error: 'empty detail response' };
    const dec = wfDecodeResource(res.raw, type);
    if (!dec) return { error: 'detail not decodable' };
    return dec;
  };

  L.wfDetails = async (list, delay) => {
    const out = [];
    for (let i = 0; i < list.length; i++) {
      if (i) await sleep(delay || 500);
      const [type, id] = list[i];
      const r = await L.wfDetail(type, id);
      out.push({ type, id, ...r });
    }
    return out;
  };

  window.__cnlit = L;
  return 'ok';
}
