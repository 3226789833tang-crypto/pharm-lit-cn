#!/usr/bin/env node
// cnlit — 知网 (CNKI) + 万方 (Wanfang) Chinese literature search MCP server.
// Zero dependencies; Node >= 18. Speaks MCP over stdio. Drives a dedicated local Chrome/Edge
// window (persistent profile) and calls the sites' own endpoints from inside the page, so the
// user's institutional IP / login applies. See ../README.md.
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import readline from 'node:readline';
import { fileURLToPath } from 'node:url';
import { BrowserManager, SITES, ToolError, log, sleep, findBrowser } from './browser.mjs';
import {
  FIELDS, CNKI_KUAKU, CNKI_ALL, WF_TYPES, TYPE_LABEL, CNKI_CORE, CNKI_CORE_NAME, WF_CORE, SORTS, CNKI_PRODUCT_LABEL,
  normaliseGroups, compileCnki, compileWanfang, addCnkiYears, addWfFilters,
  cnkiRecordFromRow, parseEndNote, parseELearning, mergeCnkiExport, mergeCnkiDetail, wfRecord,
  dedupe, toRIS, toBib, toCSV, toGBText, toMarkdown, toGB, normTitle, uniq,
} from './records.mjs';

const VERSION = '1.0.2';
const SERVER_FILE = fileURLToPath(import.meta.url);
const IS_WIN = process.platform === 'win32';
const HOME = os.homedir();
const DATA_DIR = process.env.CNLIT_DATA_DIR || (IS_WIN
  ? path.join(process.env.LOCALAPPDATA || path.join(HOME, 'AppData', 'Local'), 'cnlit')
  : path.join(HOME, '.cnlit'));
const DEFAULT_EXPORT_DIR = process.env.CNLIT_EXPORT_DIR || path.join(HOME, 'Documents', '文献检索导出');
const INTERVAL = {
  cnki: +(process.env.CNLIT_CNKI_INTERVAL_MS || 1500),
  wanfang: +(process.env.CNLIT_WANFANG_INTERVAL_MS || 1500),
};
const IDLE_CLOSE_MIN = +(process.env.CNLIT_IDLE_CLOSE_MIN || 30);
fs.mkdirSync(path.join(DATA_DIR, 'searches'), { recursive: true });

const bm = new BrowserManager(DATA_DIR);

// ---------------------------------------------------------------------------
// Store: searches and records (memory + JSON files for persistence across restarts)
// ---------------------------------------------------------------------------
const store = { searches: new Map(), records: new Map() };
const searchFile = (id) => path.join(DATA_DIR, 'searches', `${id.replace(/[^\w.-]/g, '_')}.json`);
function saveSearch(s) {
  const recs = s.keys.map((k) => store.records.get(k)).filter(Boolean);
  try { fs.writeFileSync(searchFile(s.id), JSON.stringify({ ...s, records: recs }, null, 0)); } catch (e) { log('save search failed', String(e)); }
}
function loadSearch(id) {
  if (store.searches.has(id)) return store.searches.get(id);
  try {
    const j = JSON.parse(fs.readFileSync(searchFile(id), 'utf8'));
    for (const r of j.records || []) if (!store.records.has(r.key)) store.records.set(r.key, r);
    delete j.records;
    store.searches.set(id, j);
    return j;
  } catch { return null; }
}
function putRecord(r) {
  const cur = store.records.get(r.key);
  if (cur) { for (const [k, v] of Object.entries(r)) if (v !== undefined && v !== null && v !== '' && !(Array.isArray(v) && !v.length)) cur[k] = v; return cur; }
  store.records.set(r.key, r);
  return r;
}
function findRecord(key) {
  if (store.records.has(key)) return store.records.get(key);
  // search persisted files
  try {
    for (const f of fs.readdirSync(path.join(DATA_DIR, 'searches'))) {
      const j = JSON.parse(fs.readFileSync(path.join(DATA_DIR, 'searches', f), 'utf8'));
      const r = (j.records || []).find((x) => x.key === key);
      if (r) { store.records.set(key, r); return r; }
    }
  } catch { /* ignore */ }
  return null;
}
function resaveSearchesContaining(keys) {
  const ks = new Set(keys);
  for (const s of store.searches.values()) if (s.keys.some((k) => ks.has(k))) saveSearch(s);
}
const newId = (db) => `${db}-${new Date().toISOString().slice(2, 10).replace(/-/g, '')}-${Math.random().toString(36).slice(2, 7)}`;

function appendLog(entry) {
  try { fs.appendFileSync(path.join(DATA_DIR, 'search-log.jsonl'), JSON.stringify(entry) + '\n'); } catch { /* ignore */ }
}
function readLog() {
  try {
    return fs.readFileSync(path.join(DATA_DIR, 'search-log.jsonl'), 'utf8').split('\n').filter(Boolean).map((l) => { try { return JSON.parse(l); } catch { return null; } }).filter(Boolean);
  } catch { return []; }
}
const identityCache = { cnki: '', wanfang: '' };

// ---------------------------------------------------------------------------
// Helpers
// ---------------------------------------------------------------------------
const nowStr = () => {
  const d = new Date();
  const p = (n) => String(n).padStart(2, '0');
  return `${d.getFullYear()}-${p(d.getMonth() + 1)}-${p(d.getDate())} ${p(d.getHours())}:${p(d.getMinutes())}`;
};
const trunc = (s, n) => { s = String(s || ''); return s.length > n ? s.slice(0, n) + '…' : s; };
const authorsShort = (a) => { a = a || []; return a.length > 3 ? `${a.slice(0, 3).join(', ')} 等` : a.join(', '); };

function resolveDocTypes(dt, core) {
  let list = Array.isArray(dt) ? dt : (dt ? [dt] : ['journal', 'thesis', 'conference']);
  list = uniq(list);
  if (core && core.length) list = ['journal'];
  return list;
}
function cnkiKuaku(types) {
  const t = types.includes('all') ? CNKI_ALL : types;
  return t.map((x) => CNKI_KUAKU[x]).filter(Boolean).join(',');
}
function wfTypeList(types) {
  if (types.includes('all')) return ['all'];
  return types.filter((t) => WF_TYPES[t]);
}

function buildQueries(a) {
  const field = FIELDS[a.field] ? a.field : 'topic';
  const groups = normaliseGroups(a.concept_groups, field);
  const years = (a.year_from || a.year_to) ? { from: a.year_from, to: a.year_to } : null;
  const core = uniq(a.core || []);
  const exact = a.wanfang_exact !== false;
  let cnki = null; let wanfang = null;
  if (a.cnki_query) cnki = addCnkiYears(String(a.cnki_query).trim(), years);
  else if (groups.length) cnki = compileCnki(groups, years);
  if (a.wanfang_query) wanfang = addWfFilters(String(a.wanfang_query).trim(), years, core);
  else if (groups.length) wanfang = compileWanfang(groups, years, core, exact);
  return { cnki, wanfang, groups, years, core, field };
}

function verifyError(site, extra) {
  return new ToolError(site === 'cnki' ? 'CNKI_VERIFY_REQUIRED' : 'WANFANG_VERIFY_REQUIRED',
    `${SITES[site].name}要求人工验证（滑块/登录）。已把检索浏览器窗口切到前台，请在窗口中完成验证后，再重新调用本工具。${extra || ''}`);
}

const CNKI_EMPTY_MSG = '知网返回空页，连必有结果的探针检索也为空。常见原因：①这个检索浏览器第一次访问知网，需要人工过一次验证；②短时间请求过多被拦截。已把检索窗口切到前台并打开一个知网检索页：请在窗口里看是否有拼图/滑块并完成，确认页面能正常显示结果（右上角显示机构名）后回复，再重试本工具。若窗口里检索也正常，等 30–60 秒再试。';
const WF_VERIFY_MSG = '万方触发了 IP 风控（“检测到您的 ip 有异常情况，请拖动滑块”）。已把检索窗口切到万方页面：请把滑块拖到最右边，看到正常检索结果后回复，再重试本工具。若提示“验证失败”，多为风控冷却期，过 10 分钟再拖；开着代理/VPN 出口不是校园 IP 时更容易触发，可先关闭代理。';
// Distinguish "really 0 hits" from CNKI's throttled empty page ("暂无数据，请稍后重试").
async function cnkiCanary() {
  await sleep(2500);
  const r = await bm.withSite('cnki', () => bm.call('cnki', 'cnkiGridPage', [{ expr: "SU='药学'", kuaku: CNKI_KUAKU.journal, size: 1 }, 1, null], { minInterval: INTERVAL.cnki }));
  return !!(r && r.total > 0);
}

async function cnkiGrid(o, ctx) {
  const run = () => bm.withSite('cnki', () => bm.call('cnki', 'cnkiSearch', [{ ...o, delay: INTERVAL.cnki }], { minInterval: INTERVAL.cnki, timeout: 180000 }));
  let r = await run();
  if (r && r.verify) {
    const url = 'https://kns.cnki.net/kns8s/AdvSearch?classid=WD0FTY92';
    await bm.show('cnki', url).catch(() => {});
    throw verifyError('cnki');
  }
  if (r && r.error) throw new ToolError('CNKI_ERROR', `知网请求失败：${r.error}`);
  if (r && r.empty) {
    ctx && ctx.progress && ctx.progress('知网返回“暂无数据”，复核是否限流…');
    if (!(await cnkiCanary())) {
      await bm.show('cnki', 'https://kns.cnki.net/kns8s/defaultresult/index?crossids=YSTT4HG0%2CLSTPFY1C%2CJUP3MUPD&korder=SU&kw=%E8%8D%AF%E5%AD%A6').catch(() => {});
      throw new ToolError('CNKI_CHECK_WINDOW', CNKI_EMPTY_MSG);
    }
    r = await run();
    if (r && r.verify) throw verifyError('cnki');
  }
  return r || { total: 0, rows: [] };
}

async function wfSearch(o) {
  const r = await bm.withSite('wanfang', () => bm.call('wanfang', 'wfSearch', [{ ...o, delay: INTERVAL.wanfang }], { minInterval: INTERVAL.wanfang, timeout: 180000 }));
  if (r && r.error) {
    if (/grpc-status 1\b|HTTP 40[13]|418|验证|verify/.test(r.error)) {
      await bm.show('wanfang', 'https://s.wanfangdata.com.cn/paper?q=%E8%8D%AF%E5%AD%A6').catch(() => {});
      throw new ToolError('WANFANG_VERIFY_REQUIRED', WF_VERIFY_MSG);
    }
    throw new ToolError('WANFANG_ERROR', `万方请求失败：${r.error}。如持续出现，请确认校园网/VPN 在线，或调用 lit_status 检查。`);
  }
  return r || { total: 0, items: [] };
}

// CNKI: abstracts/keywords/affiliations via the batch export endpoint (50 per request).
async function cnkiFillExport(recs, ctx) {
  const todo = recs.filter((r) => r._exportId && !r.abstract);
  for (let i = 0; i < todo.length; i += 50) {
    const batch = todo.slice(i, i + 50);
    ctx && ctx.progress && ctx.progress(`知网题录导出 ${i + batch.length}/${todo.length}`);
    const r = await bm.withSite('cnki', () => bm.call('cnki', 'cnkiExport', [batch.map((x) => x._exportId)], { minInterval: INTERVAL.cnki }));
    if (!r || r.error) { log('cnki export failed', r && r.error); continue; }
    const ens = r.en.map(parseEndNote);
    const els = r.el.map(parseELearning);
    const byTitle = new Map();
    ens.forEach((e, j) => byTitle.set(normTitle(e.title), j));
    batch.forEach((rec, j) => {
      let k = j;
      if (!ens[j] || normTitle(ens[j].title) !== normTitle(rec.title)) k = byTitle.has(normTitle(rec.title)) ? byTitle.get(normTitle(rec.title)) : -1;
      if (k >= 0) mergeCnkiExport(rec, ens[k], els[k], r.gb[k]);
    });
  }
}

async function cnkiFillDeep(recs, ctx) {
  let n = 0;
  for (const rec of recs) {
    if (rec.deep || !rec.url) continue;
    n++;
    ctx && ctx.progress && ctx.progress(`知网详情页 ${n}`);
    const d = await bm.withSite('cnki', () => bm.call('cnki', 'cnkiDetail', [rec.url], { minInterval: INTERVAL.cnki }));
    if (d && d.verify) throw verifyError('cnki', `已完成 ${n - 1} 篇。`);
    if (d && !d.error) mergeCnkiDetail(rec, d);
  }
}

async function wfFillDetails(recs, ctx, cap = 200) {
  const todo = recs.filter((r) => r.db === 'Wanfang' && !r.deep).slice(0, cap);
  for (let i = 0; i < todo.length; i += 10) {
    const batch = todo.slice(i, i + 10);
    ctx && ctx.progress && ctx.progress(`万方详情 ${i + batch.length}/${todo.length}`);
    const res = await bm.withSite('wanfang', () => bm.call('wanfang', 'wfDetails', [batch.map((r) => [r.wf_type, r.id]), INTERVAL.wanfang], { minInterval: INTERVAL.wanfang, timeout: 120000 }));
    for (const d of res || []) {
      const rec = batch.find((r) => r.id === d.id);
      if (!rec || d.error || !d.obj) continue;
      const full = wfRecord(d.type, d.obj, { detail: true });
      for (const [k, v] of Object.entries(full)) if (v !== undefined && v !== '' && !(Array.isArray(v) && !v.length)) rec[k] = v;
    }
  }
  return todo.length;
}

async function fillDetails(recs, { deep = false, ctx, wfCap = 200 } = {}) {
  const cn = recs.filter((r) => r.db === 'CNKI');
  if (cn.length) {
    await cnkiFillExport(cn, ctx);
    if (deep) await cnkiFillDeep(cn, ctx);
  }
  const wf = recs.filter((r) => r.db === 'Wanfang');
  if (wf.length) await wfFillDetails(wf, ctx, wfCap);
}

// CNKI does not show core-journal labels in the result list. For each label we re-run the same
// expression restricted to that 来源类别 with the same sort; the first N filtered hits contain every
// labelled record among the first N unfiltered hits, so one or two extra requests per label suffice.
async function cnkiAnnotateCore(base, recs, labels, ctx, depth) {
  const journals = recs.filter((r) => r.type === 'journal' && r.filename);
  if (!journals.length) return;
  const want = new Set(journals.map((r) => r.filename));
  const n = depth || recs.length;
  for (const label of labels) {
    const code = CNKI_CORE[label];
    if (!code) continue;
    ctx && ctx.progress && ctx.progress(`标注核心收录：${label}`);
    const r = await cnkiGrid({ ...base, lybsm: [code], max: Math.min(n, 200) }, ctx).catch(() => null);
    if (!r || !r.rows) continue;
    for (const row of r.rows) {
      if (!want.has(row.filename)) continue;
      const rec = journals.find((x) => x.filename === row.filename);
      if (rec) rec.core = uniq([...(rec.core || []), label]);
    }
  }
  for (const r of journals) if (!r.core) r.core = [];
}

function formatRecordLine(r, i, withAbs) {
  const meta = [r.source && r.year ? `${r.source}, ${r.year}` : (r.source || r.year), r.type_label || TYPE_LABEL[r.type]].filter(Boolean).join(' | ');
  const tags = [];
  if (r.core && r.core.length) tags.push(r.core.join('/'));
  if (r.cited) tags.push(`被引${r.cited}`);
  if (r.downloads) tags.push(`下载${r.downloads}`);
  let s = `${i}. ${r.title} — ${authorsShort(r.authors)} | ${meta}${tags.length ? ' | ' + tags.join(' ') : ''}\n   key=${r.key}`;
  if (withAbs && r.abstract) s += `\n   摘要: ${trunc(r.abstract, withAbs === true ? 300 : withAbs)}`;
  if (withAbs && r.keywords && r.keywords.length) s += `\n   关键词: ${r.keywords.join('; ')}`;
  return s;
}

// ---------------------------------------------------------------------------
// Tool implementations
// ---------------------------------------------------------------------------
async function toolStatus(a, ctx) {
  const which = a.site && a.site !== 'both' ? [a.site] : ['cnki', 'wanfang'];
  const out = [];
  const exe = findBrowser();
  out.push(`cnlit v${VERSION} | Node ${process.version} | ${process.platform}`);
  out.push(`浏览器: ${exe || '未找到（请安装 Chrome/Edge 或设置 CNLIT_BROWSER）'}`);
  if (!exe) return out.join('\n');
  for (const site of which) {
    try {
      ctx.progress(`检查${SITES[site].name}…`);
      if (site === 'cnki') {
        const id = await bm.withSite('cnki', () => bm.call('cnki', 'cnkiIdentity', []));
        const probe = await bm.withSite('cnki', () => bm.call('cnki', 'cnkiGridPage', [{ expr: "SU='药事管理'", kuaku: CNKI_KUAKU.journal, size: 1 }, 1, null], { minInterval: INTERVAL.cnki }));
        identityCache.cnki = id.institution || id.personal || '';
        const ok = probe && probe.total > 0;
        out.push(`知网: ${ok ? '可检索' : '检索异常'}；机构身份: ${id.institution || '未识别'}${id.personal ? `；个人账号: ${id.personal}` : ''}${probe && probe.verify ? '；需要滑块验证' : ''}${ok ? `（探针 SU='药事管理' 期刊 ${probe.total} 篇）` : ''}`);
        if (!ok) {
          await bm.show('cnki', 'https://kns.cnki.net/kns8s/defaultresult/index?crossids=YSTT4HG0%2CLSTPFY1C%2CJUP3MUPD&korder=SU&kw=%E8%8D%AF%E5%AD%A6').catch(() => {});
          out.push('  ' + CNKI_EMPTY_MSG);
        } else if (!id.institution) out.push('  提示: 未识别到机构身份。若不在校园网，请连 VPN，或调用 lit_open(site="cnki") 在窗口中点「机构登录」完成 CARSI 登录。');
      } else {
        const id = await bm.withSite('wanfang', () => bm.call('wanfang', 'wfIdentity', []));
        const probe = await bm.withSite('wanfang', () => bm.call('wanfang', 'wfSearchPage', [{ type: 'periodical', q: '主题:(药事管理)', size: 1 }], { minInterval: INTERVAL.wanfang }));
        identityCache.wanfang = id.institution || '';
        const ok = probe && !probe.error && probe.total > 0;
        out.push(`万方: ${ok ? '可检索' : '检索异常' + (probe && probe.error ? `（${probe.error}）` : '')}；机构身份: ${id.institution || '未识别'}${id.protoReady ? '' : '；页面解析库未就绪'}${ok ? `（探针 主题:(药事管理) 期刊 ${probe.total} 篇）` : ''}`);
        if (!ok && probe && /grpc-status 1\b/.test(probe.error || '')) {
          await bm.show('wanfang', 'https://s.wanfangdata.com.cn/paper?q=%E8%8D%AF%E5%AD%A6').catch(() => {});
          out.push('  ' + WF_VERIFY_MSG);
        } else if (!id.institution) out.push('  提示: 未识别到机构身份。请确认校园网/VPN，或调用 lit_open(site="wanfang") 登录。');
      }
    } catch (e) {
      out.push(`${SITES[site].name}: 出错 — ${e.message}`);
    }
  }
  out.push(`浏览器配置目录: ${bm.profile || '(未启动)'}`);
  out.push(`默认导出目录: ${DEFAULT_EXPORT_DIR}`);
  out.push(`数据目录: ${DATA_DIR}`);
  out.push(`服务器文件: ${SERVER_FILE}`);
  return out.join('\n');
}

async function searchCnki(a, q, types, sort, start, max, withAbs, ctx) {
  const lyb = q.core.map((c) => CNKI_CORE[c]).filter(Boolean);
  const base = { expr: q.cnki, kuaku: cnkiKuaku(types), lybsm: lyb, sortField: SORTS[sort].cnki[0], sortType: SORTS[sort].cnki[1], size: 50 };
  ctx.progress('知网检索中…');
  const r = await cnkiGrid({ ...base, max: start + max - 1 }, ctx);
  const rows = (r.rows || []).slice(start - 1, start - 1 + max);
  const recs = rows.map((row) => putRecord(cnkiRecordFromRow(row)));
  if (a.annotate_core !== false && recs.some((x) => x.type === 'journal')) {
    for (const c of q.core) for (const rr of recs) if (rr.type === 'journal') rr.core = uniq([...(rr.core || []), c]);
    const labels = q.core.length ? [] : ['北大核心', 'CSSCI', 'CSCD'];
    if (labels.length) await cnkiAnnotateCore(base, recs, labels, ctx, start - 1 + recs.length);
  }
  if (withAbs && recs.length) await cnkiFillExport(recs, ctx);
  const id = newId('cnki');
  const breakdown = Object.entries(r.groupCount || {}).filter(([, v]) => +v > 0).map(([k, v]) => `${CNKI_PRODUCT_LABEL[k] || k} ${v}`).join(' · ');
  const s = {
    id, db: 'cnki', created: nowStr(), expression: q.cnki, scope: types.map((t) => TYPE_LABEL[t] || t).join('/'),
    core: q.core, sort: SORTS[sort].label, total: r.total || 0, keys: recs.map((x) => x.key), institution: identityCache.cnki,
  };
  store.searches.set(id, s); saveSearch(s);
  appendLog({ time: s.created, search_id: id, db: '知网', expression: s.expression, scope: s.scope, core: q.core.join('/'), total: s.total, returned: recs.length, institution: s.institution });
  const text = [
    `【知网 CNKI】检索式: ${q.cnki}`,
    `范围: ${s.scope}${q.core.length ? ` | 来源类别: ${q.core.join('/')}` : ''} | 排序: ${s.sort} | 命中 ${s.total}${breakdown ? `（${breakdown}）` : ''} | 返回第 ${start}–${start + recs.length - 1} 条 | search_id=${id}`,
    ...recs.map((x, i) => formatRecordLine(x, start + i, withAbs)),
  ].join('\n');
  return { text, total: s.total, n: recs.length };
}

async function searchWanfang(a, q, types, sort, start, max, withAbs, ctx) {
  const wtypes = wfTypeList(types);
  const sortW = SORTS[sort].wf;
  const allRecs = [];
  const lines = [];
  let total = 0;
  for (const t of wtypes) {
    ctx.progress(`万方检索中（${TYPE_LABEL[t] || t}）…`);
    const startPage = Math.floor((start - 1) / 50) + 1;
    const skip = (start - 1) % 50;
    const r = await wfSearch({ type: WF_TYPES[t], q: q.wanfang, size: 50, max: skip + max, startPage, sortField: sortW ? sortW[0] : null, sortOrder: sortW ? sortW[1] : null });
    const items = (r.items || []).slice(skip, skip + max);
    const recs = items.filter((it) => it.obj).map((it) => putRecord(wfRecord(it.type, it.obj)));
    total += r.total || 0;
    lines.push(`  ${TYPE_LABEL[t] || t}: 命中 ${r.total || 0}，返回 ${recs.length}`);
    allRecs.push(...recs);
  }
  if (withAbs && allRecs.length) {
    const cap = 40;
    await wfFillDetails(allRecs, ctx, cap);
    if (allRecs.length > cap) lines.push(`  （摘要只补了前 ${cap} 条；其余用 lit_details 分批获取）`);
  }
  const id = newId('wanfang');
  const s = {
    id, db: 'wanfang', created: nowStr(), expression: q.wanfang, scope: wtypes.map((t) => TYPE_LABEL[t] || t).join('/'),
    core: q.core, sort: SORTS[sort].label, total, keys: allRecs.map((x) => x.key), institution: identityCache.wanfang,
  };
  store.searches.set(id, s); saveSearch(s);
  appendLog({ time: s.created, search_id: id, db: '万方', expression: s.expression, scope: s.scope, core: q.core.join('/'), total, returned: allRecs.length, institution: s.institution });
  const text = [
    `【万方 Wanfang】检索式: ${q.wanfang}`,
    `范围: ${s.scope} | 排序: ${s.sort} | 命中合计 ${total} | search_id=${id}`,
    ...lines,
    ...allRecs.map((x, i) => formatRecordLine(x, start + i, withAbs)),
  ].join('\n');
  return { text, total, n: allRecs.length };
}

async function toolSearch(a, ctx) {
  const db = a.db || 'both';
  const q = buildQueries(a);
  const types = resolveDocTypes(a.doc_types, q.core);
  const sort = SORTS[a.sort] ? a.sort : 'relevance';
  const max = Math.max(1, Math.min(+a.max_results || 30, 200));
  const start = Math.max(1, +a.start || 1);
  const withAbs = !!a.with_abstracts;
  if ((db === 'cnki' || db === 'both') && !q.cnki) throw new ToolError('BAD_QUERY', '缺少知网检索式：请提供 concept_groups 或 cnki_query。');
  if ((db === 'wanfang' || db === 'both') && !q.wanfang) throw new ToolError('BAD_QUERY', '缺少万方检索式：请提供 concept_groups 或 wanfang_query。');
  const jobs = [];
  if (db === 'cnki' || db === 'both') jobs.push(searchCnki(a, q, types, sort, start, max, withAbs, ctx).catch((e) => ({ error: e })));
  if (db === 'wanfang' || db === 'both') jobs.push(searchWanfang(a, q, types, sort, start, max, withAbs, ctx).catch((e) => ({ error: e })));
  const res = await Promise.all(jobs);
  const okParts = res.filter((r) => !r.error);
  const errs = res.filter((r) => r.error).map((r) => r.error);
  if (!okParts.length && errs.length) throw errs[0];
  const tips = [];
  if (okParts.some((p) => p.total > p.n)) tips.push('结果未取全：可提高 max_results（≤200）或用 start 翻页；先用 lit_count 调整检索式通常更划算。');
  if (!withAbs) tips.push('筛选前用 lit_details(search_id=…) 取摘要；导出用 lit_export。');
  return [
    ...okParts.map((p) => p.text),
    ...errs.map((e) => `[${e.code || 'ERROR'}] ${e.message}`),
  ].join('\n\n') + (tips.length ? `\n\n提示: ${tips.join(' ')}` : '');
}

async function countOne(db, expr, types, core) {
  if (db === 'cnki') {
    const lyb = (core || []).map((c) => CNKI_CORE[c]).filter(Boolean);
    const r = await cnkiGrid({ expr, kuaku: cnkiKuaku(types), lybsm: lyb, size: 1, max: 1 });
    return r.total || 0;
  }
  let total = 0;
  for (const t of wfTypeList(types)) {
    const r = await wfSearch({ type: WF_TYPES[t], q: expr, size: 1, max: 1 });
    total += r.total || 0;
  }
  return total;
}

async function toolCount(a, ctx) {
  const db = a.db || 'both';
  const dbs = db === 'both' ? ['cnki', 'wanfang'] : [db];
  const field = FIELDS[a.field] ? a.field : 'topic';
  const years = (a.year_from || a.year_to) ? { from: a.year_from, to: a.year_to } : null;
  const core = uniq(a.core || []);
  const types = resolveDocTypes(a.doc_types, core);
  const rows = [];
  const notes = [];
  let budget = Math.min(+a.max_requests || 24, 60);
  const dead = {};

  const run = async (label, exprs) => {
    const row = { label };
    for (const d of dbs) {
      if (!exprs[d]) { row[d] = '—'; continue; }
      if (dead[d]) { row[d] = `(跳过：${dead[d]})`; continue; }
      if (budget-- <= 0) { row[d] = '(超出请求上限)'; continue; }
      ctx.progress(`计数: ${label}`);
      try { row[d] = await countOne(d, exprs[d], types, core); } catch (e) {
        row[d] = `错误:${e.code || e.message}`;
        dead[d] = e.code || 'ERROR';
        if (dbs.length === 1 && e.code && /VERIFY|RATE|CHECK/.test(e.code)) throw e;
        if (e.code && /VERIFY|CHECK/.test(e.code)) notes.push(`${d === 'cnki' ? '知网' : '万方'}: ${e.message}`);
      }
    }
    row.exprs = exprs;
    rows.push(row);
  };

  for (const qq of a.queries || []) {
    if (typeof qq === 'string') {
      const looksWf = /[\u4e00-\u9fff]+\s*[:：]\s*\(/.test(qq) || /Date:/.test(qq);
      const looksCnki = /\b(SU|TKA|KY|TI|AB|AU|AF|FU|LY|CLC|FT|YE|FI|RP|DOI)\s*[%=]/.test(qq);
      const forCnki = dbs.includes('cnki') && (dbs.length === 1 || looksCnki || !looksWf);
      const forWf = dbs.includes('wanfang') && (dbs.length === 1 || looksWf || !looksCnki);
      await run(qq, { cnki: forCnki ? addCnkiYears(qq, years) : null, wanfang: forWf ? addWfFilters(qq, years, core) : null });
    } else if (qq && typeof qq === 'object') {
      const b = buildQueries({ ...a, concept_groups: qq.concept_groups, cnki_query: qq.cnki, wanfang_query: qq.wanfang, field: qq.field || field });
      await run(qq.label || b.cnki || b.wanfang, { cnki: dbs.includes('cnki') ? b.cnki : null, wanfang: dbs.includes('wanfang') ? b.wanfang : null });
    }
  }

  if (a.concept_groups) {
    const groups = normaliseGroups(a.concept_groups, field);
    const exact = a.wanfang_exact !== false;
    const comp = (gs) => ({ cnki: dbs.includes('cnki') ? compileCnki(gs, years) : null, wanfang: dbs.includes('wanfang') ? compileWanfang(gs, years, core, exact) : null });
    await run('全部概念组 AND', comp(groups));
    if (a.analyze_terms !== false) {
      const pos = groups.filter((g) => !g.not);
      if (pos.length > 1) {
        for (let i = 0; i < groups.length; i++) {
          if (groups[i].not) continue;
          await run(`去掉第${i + 1}组「${groups[i].terms.slice(0, 2).join('/')}${groups[i].terms.length > 2 ? '…' : ''}」`, comp(groups.filter((_, j) => j !== i)));
        }
      }
      for (let i = 0; i < groups.length; i++) {
        const g = groups[i];
        if (g.not || g.terms.length < 2) continue;
        for (const t of g.terms) {
          const gs = groups.map((x, j) => (j === i ? { ...x, terms: [t] } : x));
          await run(`第${i + 1}组仅用「${t}」`, comp(gs));
        }
      }
    }
  }
  const head = `| 检索 | ${dbs.map((d) => (d === 'cnki' ? '知网' : '万方')).join(' | ')} |\n|---|${dbs.map(() => '---:').join('|')}|`;
  const body = rows.map((r) => `| ${r.label} | ${dbs.map((d) => r[d]).join(' | ')} |`).join('\n');
  const exprs = rows.slice(0, 3).map((r) => dbs.map((d) => r.exprs[d] ? `  ${d === 'cnki' ? '知网' : '万方'}: ${r.exprs[d]}` : '').filter(Boolean).join('\n')).join('\n');
  return `${head}\n${body}\n\n范围: ${types.map((t) => TYPE_LABEL[t] || t).join('/')}${core.length ? ` | 来源类别: ${core.join('/')}` : ''}${years ? ` | 年份: ${years.from || ''}-${years.to || ''}` : ''}\n示例检索式:\n${exprs}${notes.length ? `\n\n注意:\n${uniq(notes).join('\n')}` : ''}`;
}

function collectRecords(a) {
  const keys = [];
  for (const sid of a.search_ids || (a.search_id ? [a.search_id] : [])) {
    const s = loadSearch(sid);
    if (!s) throw new ToolError('NOT_FOUND', `找不到 search_id=${sid}`);
    keys.push(...s.keys);
  }
  keys.push(...(a.keys || []));
  const recs = [];
  const missing = [];
  for (const k of uniq(keys)) {
    const r = findRecord(k);
    if (r) recs.push(r); else missing.push(k);
  }
  return { recs, missing };
}

async function toolDetails(a, ctx) {
  let { recs, missing } = collectRecords(a);
  const start = Math.max(1, +a.start || 1);
  const limit = Math.max(1, Math.min(+a.limit || 30, 100));
  recs = recs.slice(start - 1, start - 1 + limit);
  if (!recs.length) throw new ToolError('NOT_FOUND', '没有可取详情的记录（检查 keys / search_id）。');
  await fillDetails(recs, { deep: !!a.deep, ctx });
  resaveSearchesContaining(recs.map((r) => r.key));
  const out = recs.map((r, i) => {
    const L = [`${start + i}. ${r.title}${r.title_en ? ` / ${r.title_en}` : ''}`];
    L.push(`   ${authorsShort(r.authors)} | ${r.source || ''} ${r.year || ''}${r.volume ? `, ${r.volume}` : ''}${r.issue ? `(${r.issue})` : ''}${r.pages ? `: ${r.pages}` : ''} | ${r.type_label || TYPE_LABEL[r.type]} | ${r.db}`);
    if (r.affiliations && r.affiliations.length) L.push(`   机构: ${trunc(r.affiliations.join('; '), 200)}`);
    if (r.core && r.core.length) L.push(`   核心收录: ${r.core.join(', ')}`);
    if (r.keywords && r.keywords.length) L.push(`   关键词: ${r.keywords.join('; ')}`);
    if (r.abstract) L.push(`   摘要${r.abstract_truncated ? '(截断，deep=true 可取全文摘要)' : ''}: ${a.full_abstract === false ? trunc(r.abstract, 300) : r.abstract}`);
    else L.push('   摘要: （未获取到）');
    if (r.funds && r.funds.length) L.push(`   基金: ${r.funds.join('; ')}`);
    if (r.clc && r.clc.length) L.push(`   分类号: ${r.clc.join('; ')}`);
    if (r.degree || (r.supervisor && r.supervisor.length)) L.push(`   学位/导师: ${[r.degree, ...(r.supervisor || [])].filter(Boolean).join(' ')}`);
    if (r.doi) L.push(`   DOI: ${r.doi}`);
    L.push(`   被引 ${r.cited || 0} | 下载 ${r.downloads || 0} | key=${r.key}`);
    return L.join('\n');
  });
  const more = missing.length ? `\n\n未找到的 key: ${missing.join(', ')}` : '';
  return out.join('\n\n') + more;
}

function safeName(s) { return String(s || '').replace(/[\\/:*?"<>|\r\n]+/g, '_').trim().slice(0, 80) || 'export'; }

async function zoteroImport(ris) {
  const base = process.env.CNLIT_ZOTERO_URL || 'http://127.0.0.1:23119';
  try {
    const ping = await fetch(base + '/connector/ping', { signal: AbortSignal.timeout(3000) });
    if (!ping.ok) return `Zotero 连接器无响应（HTTP ${ping.status}）`;
  } catch { return 'Zotero 未运行（127.0.0.1:23119 无响应）：请打开 Zotero 桌面版后重试，或在 Zotero 中「文件→导入」所生成的 .ris 文件'; }
  try {
    const res = await fetch(`${base}/connector/import?session=cnlit-${Date.now()}`, {
      method: 'POST', body: ris, signal: AbortSignal.timeout(60000),
      headers: { 'Content-Type': 'application/x-research-info-systems', 'X-Zotero-Connector-API-Version': '3', 'Zotero-Allowed-Request': '1' },
    });
    const t = await res.text();
    if (res.status === 201 || res.status === 200) {
      let n = 0; try { n = JSON.parse(t).length; } catch { /* ignore */ }
      return `已导入 Zotero 当前选中的分类${n ? `（${n} 条）` : ''}`;
    }
    return `Zotero 导入失败（HTTP ${res.status}）：${t.slice(0, 120)}；请手动导入 .ris 文件`;
  } catch (e) { return `Zotero 导入失败：${e.message}；请手动导入 .ris 文件`; }
}

async function toolExport(a, ctx) {
  let { recs, missing } = collectRecords(a);
  if (!recs.length) throw new ToolError('NOT_FOUND', '没有可导出的记录（检查 keys / search_ids）。');
  const grades = a.grades || {};
  const reasons = a.grade_reasons || {};
  for (const r of recs) { if (grades[r.key]) r.grade = grades[r.key]; if (reasons[r.key]) r.grade_reason = reasons[r.key]; }
  if (a.fill_details !== false) {
    const need = recs.filter((r) => !r.abstract || (a.deep && !r.deep)).slice(0, 300);
    if (need.length) { ctx.progress(`补全 ${need.length} 条题录…`); await fillDetails(need, { deep: !!a.deep, ctx, wfCap: 300 }); resaveSearchesContaining(need.map((r) => r.key)); }
  }
  let list = recs;
  let merged = 0;
  if (a.dedupe !== false) ({ records: list, merged } = dedupe(recs));
  if (a.sort_by === 'year') list.sort((x, y) => (+y.year || 0) - (+x.year || 0));
  else if (a.sort_by === 'cited') list.sort((x, y) => (y.cited || 0) - (x.cited || 0));
  else if (a.sort_by === 'grade') list.sort((x, y) => String(x.grade || 'Z').localeCompare(String(y.grade || 'Z')));

  const dir = a.out_dir ? path.resolve(a.out_dir) : DEFAULT_EXPORT_DIR;
  fs.mkdirSync(dir, { recursive: true });
  const stamp = new Date().toISOString().slice(0, 10);
  const base = safeName(a.filename || `文献清单_${stamp}`);
  const formats = uniq(a.formats && a.formats.length ? a.formats : ['ris', 'gbt7714', 'csv']);
  const written = [];
  const write = (ext, content) => {
    const name = (i) => (ext.includes('.') ? `${base}_${ext}`.replace(/_\./, '.') : `${base}${i ? '_' + i : ''}.${ext}`);
    let p = path.join(dir, name(0));
    if (fs.existsSync(p) && !a.overwrite) {
      if (ext.includes('.')) { const [stem, e2] = [p.slice(0, p.lastIndexOf('.')), p.slice(p.lastIndexOf('.'))]; let i = 2; while (fs.existsSync(`${stem}_${i}${e2}`)) i++; p = `${stem}_${i}${e2}`; }
      else { let i = 2; while (fs.existsSync(path.join(dir, name(i)))) i++; p = path.join(dir, name(i)); }
    }
    fs.writeFileSync(p, content, 'utf8');
    written.push(p);
    return p;
  };
  let ris = null;
  for (const f of formats) {
    if (f === 'ris') ris = toRIS(list), write('ris', ris);
    else if (f === 'bib') write('bib', toBib(list));
    else if (f === 'gbt7714') write('txt', toGBText(list));
    else if (f === 'csv') write('csv', toCSV(list));
    else if (f === 'md') write('md', toMarkdown(list, a.title || base));
    else if (f === 'json') write('json', JSON.stringify(list, (k, v) => (k.startsWith('_') ? undefined : v), 2));
  }
  // Search record (检索记录) for reproducibility
  const sids = uniq([...(a.search_ids || []), ...(a.search_id ? [a.search_id] : [])]);
  const keyset = new Set(recs.map((r) => r.key));
  const logs = readLog().filter((l) => sids.includes(l.search_id) || [...store.searches.values()].some((s) => s.id === l.search_id && s.keys.some((k) => keyset.has(k))));
  if (a.include_log !== false && logs.length) {
    const L = ['# 检索记录', '', `导出时间: ${nowStr()}  `, `导出文献: ${list.length} 篇（原始 ${recs.length} 条，跨库/重复合并 ${merged} 条）`, '',
      '| 时间 | 数据库 | 检索式 | 范围 | 来源类别 | 命中 | 返回 | 机构身份 | search_id |', '|---|---|---|---|---|---:|---:|---|---|'];
    for (const l of logs) L.push(`| ${l.time} | ${l.db} | \`${String(l.expression).replace(/\|/g, '\\|')}\` | ${l.scope || ''} | ${l.core || ''} | ${l.total} | ${l.returned} | ${l.institution || ''} | ${l.search_id} |`);
    write('检索记录.md', L.join('\n') + '\n');
  }
  let zot = '';
  if (a.zotero) zot = await zoteroImport(ris || toRIS(list));
  const byDb = {};
  for (const r of list) { const k = [r.db, ...(r.also_in || [])].join('+'); byDb[k] = (byDb[k] || 0) + 1; }
  return [
    `已导出 ${list.length} 篇（输入 ${recs.length} 条，合并重复 ${merged} 条；来源分布: ${Object.entries(byDb).map(([k, v]) => `${k} ${v}`).join('，')}）`,
    ...written.map((p) => `- ${p}`),
    zot ? `Zotero: ${zot}` : '',
    missing.length ? `未找到的 key: ${missing.join(', ')}` : '',
  ].filter(Boolean).join('\n');
}

async function toolOpen(a) {
  if (a.key) {
    const r = findRecord(a.key);
    if (!r) throw new ToolError('NOT_FOUND', `找不到 key=${a.key}`);
    await bm.openTab(r.url_stable || r.url);
    return `已在检索浏览器中打开：${r.title}\n${r.url_stable || r.url}\n（可在该窗口阅读或手动下载全文；请勿批量下载。）`;
  }
  if (a.url) {
    if (!/^https?:\/\/([\w-]+\.)*(cnki\.net|wanfangdata\.com\.cn|cnki\.com\.cn)\//.test(a.url) && !a.allow_other) throw new ToolError('BAD_URL', '只允许打开知网/万方域名下的地址。');
    await bm.openTab(a.url);
    return `已打开 ${a.url}`;
  }
  const site = a.site === 'wanfang' ? 'wanfang' : 'cnki';
  const url = site === 'cnki' ? 'https://kns.cnki.net/kns8s/search?classid=WD0FTY92' : 'https://s.wanfangdata.com.cn/';
  await bm.openTab(url);
  return `已在检索浏览器中打开${SITES[site].name}首页并切到前台。\n` + (site === 'cnki'
    ? '如需登录：点击页面右上角「机构登录」→ 选择「中国药科大学」或通过 CARSI 认证；完成后告诉我，我再调用 lit_status 确认。'
    : '如需登录：点击右上角「登录」→ 机构登录 / CARSI；完成后再调用 lit_status 确认。');
}

async function toolFacets(a, ctx) {
  const q = buildQueries(a);
  if (!q.cnki) throw new ToolError('BAD_QUERY', '请提供 concept_groups 或 cnki_query。');
  const types = resolveDocTypes(a.doc_types, q.core);
  ctx.progress('知网分组统计…');
  const r = await bm.withSite('cnki', () => bm.call('cnki', 'cnkiFacets', [{ expr: q.cnki, kuaku: cnkiKuaku(types), lybsm: q.core.map((c) => CNKI_CORE[c]).filter(Boolean) }], { minInterval: INTERVAL.cnki }));
  if (!r || r.error) throw new ToolError('CNKI_ERROR', `分组统计失败：${r && r.error}`);
  const top = Math.min(+a.top || 15, 40);
  const L = [`知网分组统计 — 检索式: ${q.cnki}（范围 ${types.map((t) => TYPE_LABEL[t] || t).join('/')}）`];
  for (const [g, items] of Object.entries(r.groups || {})) {
    L.push(`\n【${g}】`);
    L.push(items.slice(0, top).map((it) => `${it.label}${g === '来源类别' ? `(${CNKI_CORE_NAME[it.value] ? it.value : ''})` : ''} ${it.count}`).join('；'));
  }
  if (Object.keys(r.groups || {}).length === 0) L.push('（无分组结果）');
  L.push('\n说明: 主题/学科分组只统计前 4 万条记录；年度、来源刊物、机构等分组知网按需加载，本工具暂不提供。');
  return L.join('\n');
}

async function toolLog(a) {
  let L = readLog();
  if (a.search_ids && a.search_ids.length) L = L.filter((l) => a.search_ids.includes(l.search_id));
  const n = Math.min(+a.last || 30, 200);
  L = L.slice(-n);
  if (!L.length) return '暂无检索记录。';
  return ['| 时间 | 数据库 | 检索式 | 范围 | 来源类别 | 命中 | 返回 | search_id |', '|---|---|---|---|---|---:|---:|---|',
    ...L.map((l) => `| ${l.time} | ${l.db} | \`${String(l.expression).replace(/\|/g, '\\|')}\` | ${l.scope || ''} | ${l.core || ''} | ${l.total} | ${l.returned} | ${l.search_id} |`)].join('\n');
}

// ---------------------------------------------------------------------------
// Tool schemas
// ---------------------------------------------------------------------------
const GROUPS_SCHEMA = {
  type: 'array',
  description: '概念组：组间 AND、组内同义词 OR。例 [["药物性肝损伤","药物性肝损害","药源性肝损伤"],["信号检测","信号挖掘","不相称性分析"]]。某组可写成对象 {"terms":[...],"field":"title","not":true} 以单独指定字段或作为排除组(NOT)。',
  items: { anyOf: [{ type: 'array', items: { type: 'string' } }, { type: 'object', properties: { terms: { type: 'array', items: { type: 'string' } }, field: { type: 'string', enum: Object.keys(FIELDS) }, not: { type: 'boolean' } }, required: ['terms'] }] },
};
const COMMON_FILTERS = {
  field: { type: 'string', enum: Object.keys(FIELDS), default: 'topic', description: '概念组默认检索字段：topic=主题(知网SU/万方主题) | tka=篇关摘 | title_keyword=题名或关键词 | title=题名 | keyword=关键词 | abstract=摘要' },
  year_from: { type: 'integer', description: '起始年（含）' },
  year_to: { type: 'integer', description: '截止年（含）' },
  doc_types: { type: 'array', items: { type: 'string', enum: ['journal', 'thesis', 'conference', 'newspaper', 'standard', 'patent', 'achievement', 'book', 'series', 'special_journal', 'all'] }, description: '文献类型，默认 ["journal","thesis","conference"]；"all"=知网总库/万方全部。万方多类型会分别检索后合并。' },
  core: { type: 'array', items: { type: 'string', enum: ['北大核心', 'CSSCI', 'CSCD', 'SCI', 'EI', 'WJCI', 'AMI', '科技核心'] }, description: '只要这些来源类别的期刊（多选为 OR，自动限定为期刊）。科技核心仅万方；WJCI/AMI 仅知网。' },
  wanfang_exact: { type: 'boolean', default: true, description: '万方检索词是否加引号精确匹配（默认 true，避免切词带来的噪声）' },
};

const TOOLS = [
  {
    name: 'lit_status',
    description: '启动/检查本机的文献检索浏览器，报告知网、万方是否可检索及机构身份（IP 或登录）。首次使用、报错后、或换网络后先调用。',
    inputSchema: { type: 'object', properties: { site: { type: 'string', enum: ['both', 'cnki', 'wanfang'], default: 'both' } } },
    annotations: { readOnlyHint: true },
    handler: toolStatus,
  },
  {
    name: 'lit_count',
    description: '只算命中数、不取题录，用于调检索式：批量比较多个检索式，或对 concept_groups 做“去掉某组 / 某组只用某个词”的贡献分析，找出过窄、过宽或无效的同义词。正式检索前先用它。',
    inputSchema: {
      type: 'object',
      properties: {
        db: { type: 'string', enum: ['both', 'cnki', 'wanfang'], default: 'both' },
        queries: { type: 'array', description: '要比较的检索式。字符串=按所选库原样执行（知网专业检索式或万方专业检索式）；对象 {label, cnki, wanfang, concept_groups} 可分别给两库。', items: { anyOf: [{ type: 'string' }, { type: 'object', properties: { label: { type: 'string' }, cnki: { type: 'string' }, wanfang: { type: 'string' }, concept_groups: GROUPS_SCHEMA } }] } },
        concept_groups: GROUPS_SCHEMA,
        analyze_terms: { type: 'boolean', default: true, description: '对 concept_groups 做逐组、逐词贡献分析' },
        max_requests: { type: 'integer', default: 24, description: '本次最多发出的计数请求数（上限 60；万方风控较严，单次不宜过多）' },
        ...COMMON_FILTERS,
      },
    },
    annotations: { readOnlyHint: true },
    handler: toolCount,
  },
  {
    name: 'lit_search',
    description: '在知网和/或万方检索中文文献，返回命中总数、可复现的检索式和题录列表（题名/作者/来源/年/类型/核心收录/被引/下载），并生成 search_id 供后续取摘要、导出。用 concept_groups 自动编译两库检索式，或用 cnki_query / wanfang_query 直接给专业检索式。',
    inputSchema: {
      type: 'object',
      properties: {
        db: { type: 'string', enum: ['both', 'cnki', 'wanfang'], default: 'both' },
        concept_groups: GROUPS_SCHEMA,
        cnki_query: { type: 'string', description: "知网专业检索式，如 SU=('药物警戒'+'药品不良反应') AND SU='信号检测' NOT SU='中药'。给出时覆盖 concept_groups。年份用 year_from/year_to。" },
        wanfang_query: { type: 'string', description: '万方专业检索式，如 主题:("药物警戒" or "药品不良反应") and 主题:("信号检测")。给出时覆盖 concept_groups。' },
        sort: { type: 'string', enum: Object.keys(SORTS), default: 'relevance' },
        max_results: { type: 'integer', default: 30, description: '每库返回条数（≤200；万方为每种文献类型）' },
        start: { type: 'integer', default: 1, description: '从第几条开始（翻页）' },
        with_abstracts: { type: 'boolean', default: false, description: '同时取摘要和关键词（知网批量很快；万方逐条，最多 40 条）' },
        annotate_core: { type: 'boolean', default: true, description: '知网：为期刊结果标注北大核心/CSSCI/CSCD（每个类别多 1–2 次请求）' },
        ...COMMON_FILTERS,
      },
    },
    annotations: { readOnlyHint: true },
    handler: toolSearch,
  },
  {
    name: 'lit_details',
    description: '获取记录的完整题录：摘要、关键词、作者机构、卷期页、DOI、基金、分类号、学位/导师。用于按标题+摘要筛选与分级。知网默认走批量导出（摘要可能被截断，deep=true 逐篇读详情页取全摘要、基金、分类号）。',
    inputSchema: {
      type: 'object',
      properties: {
        keys: { type: 'array', items: { type: 'string' }, description: '记录 key（lit_search 输出中的 key=…）' },
        search_id: { type: 'string', description: '或给 search_id，取该次检索的记录' },
        start: { type: 'integer', default: 1 },
        limit: { type: 'integer', default: 30, description: '本次最多处理条数（≤100）' },
        deep: { type: 'boolean', default: false },
        full_abstract: { type: 'boolean', default: true },
      },
    },
    annotations: { readOnlyHint: true },
    handler: toolDetails,
  },
  {
    name: 'lit_export',
    description: '把选定记录跨库去重后导出到本机文件：RIS（Zotero/EndNote/NoteExpress）、GB/T 7714 参考文献文本、CSV（Excel）、BibTeX、Markdown、JSON，并附检索记录表；可选直接导入正在运行的 Zotero。可附相关性分级。',
    inputSchema: {
      type: 'object',
      properties: {
        keys: { type: 'array', items: { type: 'string' }, description: '要导出的记录 key（筛选后的纳入文献）' },
        search_ids: { type: 'array', items: { type: 'string' }, description: '或导出这些检索的全部记录' },
        formats: { type: 'array', items: { type: 'string', enum: ['ris', 'gbt7714', 'csv', 'bib', 'md', 'json'] }, default: ['ris', 'gbt7714', 'csv'] },
        filename: { type: 'string', description: '文件名（不含扩展名），如 “DILI信号检测_中文文献_2026-10-23”' },
        out_dir: { type: 'string', description: '输出目录（本机绝对路径）；默认 文档\\文献检索导出' },
        grades: { type: 'object', additionalProperties: { type: 'string' }, description: '可选：{key: "A"|"B"|"C"} 相关性分级，写入 CSV/RIS' },
        grade_reasons: { type: 'object', additionalProperties: { type: 'string' }, description: '可选：{key: 分级理由}' },
        sort_by: { type: 'string', enum: ['input', 'year', 'cited', 'grade'], default: 'input' },
        dedupe: { type: 'boolean', default: true },
        fill_details: { type: 'boolean', default: true, description: '导出前自动补摘要等字段' },
        deep: { type: 'boolean', default: false, description: '知网逐篇读详情页补基金/分类号/DOI（慢）' },
        zotero: { type: 'boolean', default: false, description: '同时导入正在运行的 Zotero（当前选中的分类）' },
        include_log: { type: 'boolean', default: true },
        title: { type: 'string', description: 'Markdown 清单标题' },
        overwrite: { type: 'boolean', default: false },
      },
    },
    handler: toolExport,
  },
  {
    name: 'lit_open',
    description: '在检索浏览器窗口中打开并前置：某条记录的详情页（key）、知网/万方地址（url），或站点首页（site，用于机构登录/CARSI、完成滑块验证）。用于用户需要亲自阅读、手动下载全文或登录时。',
    inputSchema: { type: 'object', properties: { key: { type: 'string' }, url: { type: 'string' }, site: { type: 'string', enum: ['cnki', 'wanfang'] } } },
    handler: toolOpen,
  },
  {
    name: 'lit_facets',
    description: '知网分组统计：给定检索式的主要主题、次要主题、学科、来源类别分布。用于发现同义词/相关主题词、判断学科分布和核心期刊占比。',
    inputSchema: {
      type: 'object',
      properties: {
        concept_groups: GROUPS_SCHEMA,
        cnki_query: { type: 'string' },
        top: { type: 'integer', default: 15 },
        ...COMMON_FILTERS,
      },
    },
    annotations: { readOnlyHint: true },
    handler: toolFacets,
  },
  {
    name: 'lit_log',
    description: '列出最近的检索记录（时间、数据库、检索式、范围、命中数、search_id），用于写检索日志/方法学描述。',
    inputSchema: { type: 'object', properties: { last: { type: 'integer', default: 30 }, search_ids: { type: 'array', items: { type: 'string' } } } },
    annotations: { readOnlyHint: true },
    handler: toolLog,
  },
];

// ---------------------------------------------------------------------------
// MCP stdio protocol (JSON-RPC 2.0, newline-delimited)
// ---------------------------------------------------------------------------
const SUPPORTED_PROTOCOLS = ['2025-06-18', '2025-03-26', '2024-11-05'];
const INSTRUCTIONS = '中文文献检索（知网 CNKI + 万方）。流程：lit_status 确认机构身份 → lit_count 调检索式 → lit_search 取题录 → lit_details 取摘要筛选 → lit_export 导出。遇到 *_VERIFY_REQUIRED 或 CNKI_CHECK_WINDOW：把错误信息转告用户，请其在已前置的检索浏览器窗口完成验证后再重试；不要连续重试。';

function send(msg) { process.stdout.write(JSON.stringify(msg) + '\n'); }

async function handle(msg) {
  const { id, method, params } = msg;
  const isReq = id !== undefined && id !== null;
  try {
    if (method === 'initialize') {
      const v = params && params.protocolVersion;
      return isReq && send({ jsonrpc: '2.0', id, result: {
        protocolVersion: SUPPORTED_PROTOCOLS.includes(v) ? v : SUPPORTED_PROTOCOLS[0],
        capabilities: { tools: { listChanged: false } },
        serverInfo: { name: 'cnlit', title: '知网+万方中文文献检索', version: VERSION },
        instructions: INSTRUCTIONS,
      } });
    }
    if (method === 'ping') return isReq && send({ jsonrpc: '2.0', id, result: {} });
    if (method === 'tools/list') {
      return isReq && send({ jsonrpc: '2.0', id, result: { tools: TOOLS.map(({ handler, ...t }) => t) } });
    }
    if (method === 'resources/list') return isReq && send({ jsonrpc: '2.0', id, result: { resources: [] } });
    if (method === 'prompts/list') return isReq && send({ jsonrpc: '2.0', id, result: { prompts: [] } });
    if (method === 'tools/call') {
      const tool = TOOLS.find((t) => t.name === (params && params.name));
      if (!tool) return isReq && send({ jsonrpc: '2.0', id, error: { code: -32602, message: `Unknown tool: ${params && params.name}` } });
      const token = params._meta && params._meta.progressToken;
      let step = 0;
      const ctx = {
        progress: (message) => {
          if (token === undefined) return;
          step++;
          send({ jsonrpc: '2.0', method: 'notifications/progress', params: { progressToken: token, progress: step, message } });
        },
      };
      try {
        const text = await tool.handler(params.arguments || {}, ctx);
        return isReq && send({ jsonrpc: '2.0', id, result: { content: [{ type: 'text', text: String(text) }] } });
      } catch (e) {
        const code = e.code || 'ERROR';
        log('tool error', tool.name, code, e.stack || e.message);
        return isReq && send({ jsonrpc: '2.0', id, result: { isError: true, content: [{ type: 'text', text: `[${code}] ${e.message}` }] } });
      }
    }
    if (method && method.startsWith('notifications/')) return;
    if (isReq) send({ jsonrpc: '2.0', id, error: { code: -32601, message: `Method not found: ${method}` } });
  } catch (e) {
    if (isReq) send({ jsonrpc: '2.0', id, error: { code: -32603, message: String(e && e.message) } });
  }
}

const rl = readline.createInterface({ input: process.stdin, crlfDelay: Infinity });
rl.on('line', (line) => {
  line = line.trim();
  if (!line) return;
  let msg;
  try { msg = JSON.parse(line); } catch { return send({ jsonrpc: '2.0', id: null, error: { code: -32700, message: 'Parse error' } }); }
  if (Array.isArray(msg)) msg.forEach((m) => handle(m)); else handle(msg);
});
const shutdown = async () => { try { await bm.close(); } catch { /* ignore */ } process.exit(0); };
rl.on('close', shutdown);
process.on('SIGTERM', shutdown);
process.on('SIGINT', shutdown);
process.on('unhandledRejection', (e) => log('unhandledRejection', String(e && e.stack || e)));

setInterval(() => {
  if (bm.running && bm.lastUse && Date.now() - bm.lastUse > IDLE_CLOSE_MIN * 60000) { log('idle: closing browser'); bm.close(); }
}, 60000).unref();

log(`cnlit ${VERSION} ready (data: ${DATA_DIR})`);
