// Minimal Chrome DevTools Protocol client over --remote-debugging-pipe (no WebSocket, no open port).
import { spawn } from 'node:child_process';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import { cnlitPageLib } from './pagelib.mjs';

const IS_WIN = process.platform === 'win32';
export const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
export const log = (...a) => {
  try { process.stderr.write('[cnlit] ' + a.map((x) => (typeof x === 'string' ? x : JSON.stringify(x))).join(' ') + '\n'); } catch { /* ignore */ }
};

export class ToolError extends Error {
  constructor(code, message) { super(message); this.code = code; }
}

class CDPConnection {
  constructor(writeStream, readStream) {
    this.w = writeStream;
    this.id = 0;
    this.cb = new Map();
    this.listeners = [];
    this.closed = false;
    let pending = [];
    readStream.on('data', (buf) => {
      let start = 0;
      for (let i = 0; i < buf.length; i++) {
        if (buf[i] === 0) {
          pending.push(buf.subarray(start, i));
          const msg = Buffer.concat(pending).toString('utf8');
          pending = [];
          start = i + 1;
          this._onMessage(msg);
        }
      }
      if (start < buf.length) pending.push(Buffer.from(buf.subarray(start)));
    });
    readStream.on('close', () => this._onClose());
    readStream.on('error', () => this._onClose());
    writeStream.on('error', () => this._onClose());
  }

  _onMessage(s) {
    let m;
    try { m = JSON.parse(s); } catch { return; }
    if (m.id !== undefined) {
      const c = this.cb.get(m.id);
      if (!c) return;
      this.cb.delete(m.id);
      clearTimeout(c.t);
      if (m.error) c.reject(new Error(`${c.method}: ${m.error.message}`));
      else c.resolve(m.result);
    } else {
      for (const l of this.listeners) { try { l(m); } catch { /* ignore */ } }
    }
  }

  _onClose() {
    if (this.closed) return;
    this.closed = true;
    for (const c of this.cb.values()) { clearTimeout(c.t); c.reject(new Error('浏览器连接已断开')); }
    this.cb.clear();
  }

  send(method, params = {}, sessionId, timeoutMs = 60000) {
    if (this.closed) return Promise.reject(new Error('浏览器连接已断开'));
    const id = ++this.id;
    const msg = { id, method, params };
    if (sessionId) msg.sessionId = sessionId;
    return new Promise((resolve, reject) => {
      const t = setTimeout(() => { this.cb.delete(id); reject(new Error(`CDP 超时: ${method}`)); }, timeoutMs);
      this.cb.set(id, { resolve, reject, method, t });
      try { this.w.write(JSON.stringify(msg) + '\0'); } catch (e) { clearTimeout(t); this.cb.delete(id); reject(e); }
    });
  }

  on(fn) { this.listeners.push(fn); return () => { this.listeners = this.listeners.filter((x) => x !== fn); }; }
}

export function findBrowser() {
  const env = process.env.CNLIT_BROWSER;
  if (env && fs.existsSync(env)) return env;
  const c = [];
  const home = os.homedir();
  if (IS_WIN) {
    const pf = process.env.PROGRAMFILES || 'C:\\Program Files';
    const pf86 = process.env['PROGRAMFILES(X86)'] || 'C:\\Program Files (x86)';
    const la = process.env.LOCALAPPDATA || path.join(home, 'AppData', 'Local');
    c.push(
      path.join(pf, 'Google', 'Chrome', 'Application', 'chrome.exe'),
      path.join(pf86, 'Google', 'Chrome', 'Application', 'chrome.exe'),
      path.join(la, 'Google', 'Chrome', 'Application', 'chrome.exe'),
      path.join(pf86, 'Microsoft', 'Edge', 'Application', 'msedge.exe'),
      path.join(pf, 'Microsoft', 'Edge', 'Application', 'msedge.exe'),
    );
  } else if (process.platform === 'darwin') {
    c.push(
      '/Applications/Google Chrome.app/Contents/MacOS/Google Chrome',
      '/Applications/Microsoft Edge.app/Contents/MacOS/Microsoft Edge',
      '/Applications/Chromium.app/Contents/MacOS/Chromium',
    );
  } else {
    c.push('/usr/bin/google-chrome', '/usr/bin/google-chrome-stable', '/usr/bin/chromium', '/usr/bin/chromium-browser', '/usr/bin/microsoft-edge');
  }
  return c.find((p) => { try { return fs.statSync(p).isFile(); } catch { return false; } }) || null;
}

const originOf = (u) => { try { return new URL(u).origin; } catch { return ''; } };
const CNKI_HOME = process.env.CNLIT_CNKI_HOME || 'https://kns.cnki.net/kns8s/search?classid=WD0FTY92';
const WF_HOME = process.env.CNLIT_WANFANG_HOME || 'https://d.wanfangdata.com.cn/periodical/ywlxbxzz202208006';
export const SITES = {
  cnki: {
    name: '知网',
    home: CNKI_HOME,
    origin: originOf(CNKI_HOME),
    ready: 'document.readyState !== "loading"',
  },
  wanfang: {
    name: '万方',
    home: WF_HOME,
    origin: originOf(WF_HOME),
    ready: 'typeof proto !== "undefined" && !!proto.Periodical',
  },
};

const LIB_SRC = '(' + cnlitPageLib.toString() + ')()';

export class BrowserManager {
  constructor(dataDir) {
    this.dataDir = dataDir;
    this.proc = null;
    this.cdp = null;
    this.exe = null;
    this.profile = null;
    this.sessions = {};
    this.launching = null;
    this.lastUse = 0;
    this.locks = {};
    this.lastCall = {};
    this.headless = process.env.CNLIT_HEADLESS === '1';
    this.minimize = process.env.CNLIT_MINIMIZE !== '0';
  }

  get running() { return !!(this.cdp && !this.cdp.closed); }

  async ensure() {
    if (this.running) return;
    if (this.launching) return this.launching;
    this.launching = this._launchWithFallback().finally(() => { this.launching = null; });
    return this.launching;
  }

  async _launchWithFallback() {
    const exe = findBrowser();
    if (!exe) throw new ToolError('BROWSER_NOT_FOUND', '没有找到 Chrome 或 Edge。请安装其中之一，或设置环境变量 CNLIT_BROWSER 指向浏览器程序（chrome.exe / msedge.exe）。');
    const profiles = [path.join(this.dataDir, 'browser-profile'), path.join(this.dataDir, 'browser-profile-2'), path.join(os.tmpdir(), `cnlit-profile-${process.pid}`)];
    let lastErr;
    for (const p of profiles) {
      try { await this._launch(exe, p); return; } catch (e) { lastErr = e; log('launch failed with profile', p, String(e)); }
    }
    throw new ToolError('BROWSER_LAUNCH_FAILED', `浏览器启动失败：${lastErr && lastErr.message}`);
  }

  async _launch(exe, profileDir) {
    fs.mkdirSync(profileDir, { recursive: true });
    const args = [
      '--remote-debugging-pipe',
      `--user-data-dir=${profileDir}`,
      '--no-first-run', '--no-default-browser-check',
      '--disable-background-timer-throttling', '--disable-backgrounding-occluded-windows', '--disable-renderer-backgrounding',
      '--disable-features=Translate,MediaRouter,OptimizationHints,AutofillServerCommunication',
      '--disable-popup-blocking', '--window-size=1280,900', '--lang=zh-CN',
    ];
    if (this.headless) args.push('--headless=new');
    if (process.env.CNLIT_EXTRA_ARGS) args.push(...process.env.CNLIT_EXTRA_ARGS.split(/\s+/).filter(Boolean));
    args.push('about:blank');
    const proc = spawn(exe, args, { stdio: ['ignore', 'ignore', 'pipe', 'pipe', 'pipe'], windowsHide: false });
    let errTail = '';
    proc.stderr.on('data', (d) => { errTail = (errTail + d.toString()).slice(-600); });
    let spawnErr = null;
    proc.on('error', (e) => { spawnErr = e; });
    const cdp = new CDPConnection(proc.stdio[3], proc.stdio[4]);
    const exited = new Promise((_, rej) => proc.once('exit', (code) => rej(new Error(`浏览器进程提前退出 (code ${code})，可能该配置目录正被另一个实例占用`))));
    exited.catch(() => {});
    try {
      await Promise.race([cdp.send('Browser.getVersion', {}, undefined, 30000), exited]);
    } catch (e) {
      try { proc.kill(); } catch { /* ignore */ }
      const tail = errTail.split('\n').map((x) => x.trim()).filter(Boolean).slice(-3).join(' / ');
      throw new Error(`${spawnErr ? spawnErr.message : e.message}${tail ? ' | ' + tail : ''}`);
    }
    this.proc = proc;
    this.cdp = cdp;
    this.exe = exe;
    this.profile = profileDir;
    this.sessions = {};
    proc.on('exit', () => {
      if (this.proc === proc) { this.proc = null; this.cdp = null; this.sessions = {}; }
    });
    cdp.on((m) => {
      if (m.method === 'Target.detachedFromTarget') {
        for (const k of Object.keys(this.sessions)) if (this.sessions[k].sessionId === m.params.sessionId) delete this.sessions[k];
      }
    });
    log('browser launched', exe, profileDir);
  }

  async close() {
    if (!this.running) return;
    try { await this.cdp.send('Browser.close', {}, undefined, 5000); } catch { /* ignore */ }
    try { this.proc && this.proc.kill(); } catch { /* ignore */ }
    this.proc = null; this.cdp = null; this.sessions = {};
  }

  async evalRaw(s, expression, timeout = 60000) {
    const r = await this.cdp.send('Runtime.evaluate', { expression, awaitPromise: true, returnByValue: true, userGesture: true }, s.sessionId, timeout + 2000);
    if (r.exceptionDetails) {
      const d = r.exceptionDetails;
      throw new Error('页面脚本错误: ' + ((d.exception && d.exception.description) || d.text || 'unknown'));
    }
    return r.result ? r.result.value : undefined;
  }

  async _attachNew(url = 'about:blank') {
    const { targetInfos } = await this.cdp.send('Target.getTargets');
    const used = new Set(Object.values(this.sessions).map((x) => x.targetId));
    const blank = targetInfos.find((t) => t.type === 'page' && t.url === 'about:blank' && !used.has(t.targetId));
    let targetId;
    if (blank) targetId = blank.targetId;
    else ({ targetId } = await this.cdp.send('Target.createTarget', { url: 'about:blank' }));
    const { sessionId } = await this.cdp.send('Target.attachToTarget', { targetId, flatten: true });
    await this.cdp.send('Page.enable', {}, sessionId).catch(() => {});
    const s = { targetId, sessionId };
    if (url !== 'about:blank') await this.navigate(s, url);
    return s;
  }

  async navigate(s, url, readyExpr, timeout = 45000) {
    await this.cdp.send('Page.navigate', { url }, s.sessionId, timeout);
    const t0 = Date.now();
    await sleep(800);
    while (Date.now() - t0 < timeout) {
      try {
        const st = await this.evalRaw(s, 'document.readyState + "|" + location.href', 5000);
        if (/^(interactive|complete)\|/.test(st) && !/\|about:blank/.test(st)) break;
      } catch { /* navigating */ }
      await sleep(500);
    }
    if (readyExpr) {
      while (Date.now() - t0 < timeout) {
        try { if (await this.evalRaw(s, `!!(${readyExpr})`, 5000)) break; } catch { /* ignore */ }
        await sleep(500);
      }
    }
  }

  async page(site, { fresh = false } = {}) {
    await this.ensure();
    const cfg = SITES[site];
    let s = this.sessions[site];
    if (s) {
      try {
        const st = await this.evalRaw(s, 'location.origin + "|" + (typeof window.__cnlit) + "|" + document.readyState', 8000);
        const [orig, t] = String(st).split('|');
        if (!fresh && orig === cfg.origin && t === 'object') return s;
        if (fresh || orig !== cfg.origin) await this.navigate(s, cfg.home, cfg.ready);
        await this.inject(s);
        return s;
      } catch (e) {
        log('session lost', site, String(e));
        delete this.sessions[site];
      }
    }
    s = await this._attachNew();
    this.sessions[site] = s;
    await this.navigate(s, cfg.home, cfg.ready);
    await this.inject(s);
    if (this.minimize && !this._minimizedOnce) {
      this._minimizedOnce = true;
      this.setWindowState(s, 'minimized').catch(() => {});
    }
    return s;
  }

  async inject(s) {
    const r = await this.evalRaw(s, LIB_SRC, 15000);
    if (r !== 'ok') throw new Error('页面辅助脚本注入失败');
  }

  async setWindowState(s, state) {
    const { windowId } = await this.cdp.send('Browser.getWindowForTarget', { targetId: s.targetId });
    await this.cdp.send('Browser.setWindowBounds', { windowId, bounds: { windowState: state } });
  }

  async show(site, url) {
    const s = await this.page(site);
    if (url) await this.navigate(s, url, null, 30000);
    await this.cdp.send('Page.bringToFront', {}, s.sessionId).catch(() => {});
    await this.setWindowState(s, 'normal').catch(() => {});
    return s;
  }

  async openTab(url) {
    await this.ensure();
    const { targetId } = await this.cdp.send('Target.createTarget', { url });
    try {
      await this.cdp.send('Target.activateTarget', { targetId });
      const { windowId } = await this.cdp.send('Browser.getWindowForTarget', { targetId });
      await this.cdp.send('Browser.setWindowBounds', { windowId, bounds: { windowState: 'normal' } });
    } catch { /* ignore */ }
    return targetId;
  }

  // Serialise calls per site and keep a minimum interval between network operations.
  async withSite(site, fn) {
    const prev = this.locks[site] || Promise.resolve();
    let release;
    const cur = new Promise((r) => { release = r; });
    this.locks[site] = prev.then(() => cur);
    await prev.catch(() => {});
    try { return await fn(); } finally { release(); }
  }

  async throttle(site, minMs) {
    const last = this.lastCall[site] || 0;
    const wait = last + minMs + Math.floor(Math.random() * 300) - Date.now();
    if (wait > 0) await sleep(wait);
    this.lastCall[site] = Date.now();
  }

  // Call a window.__cnlit function in the site tab. One automatic retry if the page context was lost.
  async call(site, fn, args, { timeout = 90000, minInterval = 0 } = {}) {
    this.lastUse = Date.now();
    const expr = `window.__cnlit.${fn}(...${JSON.stringify(args || [])})`;
    for (let attempt = 0; attempt < 2; attempt++) {
      const s = await this.page(site);
      if (minInterval) await this.throttle(site, minInterval);
      try {
        const r = await this.evalRaw(s, expr, timeout);
        this.lastUse = Date.now();
        return r;
      } catch (e) {
        const msg = String(e && e.message);
        if (attempt === 0 && /context|destroyed|Cannot find|__cnlit|not a function|undefined/.test(msg)) {
          log('retry after', msg);
          await sleep(1000);
          continue;
        }
        throw e;
      }
    }
    return undefined;
  }
}
