// Query compilation, record normalisation, de-duplication and export formats.
import crypto from 'node:crypto';

export const uniq = (a) => [...new Set((a || []).filter((x) => x !== undefined && x !== null && String(x).trim() !== '').map((x) => String(x).trim()))];
export const stripTags = (s) => (s == null ? '' : String(s))
  .replace(/<[^>]+>/g, '')
  .replace(/&nbsp;/g, ' ').replace(/&lt;/g, '<').replace(/&gt;/g, '>')
  .replace(/&quot;/g, '"').replace(/&#39;/g, "'").replace(/&amp;/g, '&')
  .replace(/\s+/g, ' ').trim();
const shortHash = (s) => crypto.createHash('md5').update(String(s)).digest('hex').slice(0, 10);

// ---------------------------------------------------------------------------
// Fields, document types, core-journal labels, sorting
// ---------------------------------------------------------------------------
export const FIELDS = {
  topic: { cnki: 'SU', wf: '主题', label: '主题' },
  tka: { cnki: 'TKA', wf: '主题', label: '篇关摘' },
  title_keyword: { cnki: ['TI', 'KY'], wf: '题名或关键词', label: '题名或关键词' },
  title: { cnki: 'TI', wf: '题名', label: '题名' },
  keyword: { cnki: 'KY', wf: '关键词', label: '关键词' },
  abstract: { cnki: 'AB', wf: '摘要', label: '摘要' },
};

export const CNKI_KUAKU = {
  journal: 'YSTT4HG0', thesis: 'LSTPFY1C', conference: 'JUP3MUPD', newspaper: 'MPMFIG1A',
  book: 'EMRPGLPA', standard: 'WQ0UVIAA', achievement: 'BLZOG7CK', series: 'PWFIRAGL',
  special_journal: 'NN3FJMUV', video: 'NLBO1Z6R',
};
export const CNKI_ALL = ['journal', 'thesis', 'conference', 'newspaper', 'standard', 'achievement', 'series', 'book', 'video', 'special_journal'];
export const WF_TYPES = { journal: 'periodical', thesis: 'thesis', conference: 'conference', patent: 'patent', standard: 'standard', achievement: 'cstad', all: 'paper' };
export const TYPE_LABEL = {
  journal: '期刊', thesis: '学位论文', conference: '会议', newspaper: '报纸', book: '图书', standard: '标准',
  patent: '专利', achievement: '成果', series: '学术辑刊', special_journal: '特色期刊', video: '视频', law: '法规', report: '科技报告', other: '其他', all: '全部',
};

// CNKI 来源类别 (LYBSM) codes, verified 2026-10.
export const CNKI_CORE = { 北大核心: 'P01', CSSCI: 'P0209', CSCD: 'P0210', SCI: 'P0201', EI: 'P0202', WJCI: 'P12', AMI: 'P13' };
export const CNKI_CORE_NAME = Object.fromEntries(Object.entries(CNKI_CORE).map(([k, v]) => [v, k]));
// Wanfang 核心收录 values.
export const WF_CORE = { 北大核心: '北大核心', CSSCI: 'CSSCI', CSCD: 'CSCD', SCI: 'SCI', EI: 'EI', 科技核心: 'ISTIC' };
const WF_CORE_LABEL = { PKU: '北大核心', 北大核心: '北大核心', CSSCI: 'CSSCI', CSCD: 'CSCD', ISTIC: '科技核心', SCI: 'SCI', EI: 'EI', CA: 'CA', 'CSSCI(扩展)': 'CSSCI扩展' };

export const SORTS = {
  relevance: { cnki: ['FFD', 'desc'], wf: null, label: '相关度' },
  date: { cnki: ['PT', 'desc'], wf: ['出版时间', 1], label: '发表时间(新→旧)' },
  cited: { cnki: ['CF', 'desc'], wf: ['被引频次', 1], label: '被引频次' },
  downloads: { cnki: ['DFR', 'desc'], wf: ['下载量', 1], label: '下载量' },
};

// ---------------------------------------------------------------------------
// Expression compilation
// ---------------------------------------------------------------------------
export function normaliseGroups(groups, defaultField) {
  if (!Array.isArray(groups)) return [];
  return groups.map((g) => {
    if (Array.isArray(g)) return { terms: uniq(g), field: defaultField, not: false };
    if (g && typeof g === 'object') return { terms: uniq(g.terms || g.synonyms || []), field: g.field || defaultField, not: !!(g.not || g.exclude) };
    if (typeof g === 'string') return { terms: uniq(g.split(/[|｜,，;；]/)), field: defaultField, not: false };
    return null;
  }).filter((g) => g && g.terms.length);
}

const cnkiQuote = (t) => `'${String(t).replace(/['‘’]/g, '').trim()}'`;
function cnkiClause(field, terms) {
  const code = (FIELDS[field] || FIELDS.topic).cnki;
  if (Array.isArray(code)) return '(' + code.map((c) => cnkiClauseCode(c, terms)).join(' OR ') + ')';
  return cnkiClauseCode(code, terms);
}
function cnkiClauseCode(code, terms) {
  // NB: CNKI treats SU=('x') (single term in parentheses) differently from SU='x', so never wrap one term.
  if (terms.length === 1) return `${code}=${cnkiQuote(terms[0])}`;
  return `${code}=(${terms.map(cnkiQuote).join('+')})`;
}

const wfQuote = (t, exact) => {
  const s = String(t).replace(/["“”]/g, '').trim();
  return exact ? `"${s}"` : s;
};
function wfClause(field, terms, exact) {
  const f = (FIELDS[field] || FIELDS.topic).wf;
  if (terms.length === 1) return `${f}:(${wfQuote(terms[0], exact)})`;
  return `${f}:(${terms.map((t) => wfQuote(t, exact)).join(' or ')})`;
}

export function compileCnki(groups, years) {
  const pos = groups.filter((g) => !g.not).map((g) => cnkiClause(g.field, g.terms));
  const neg = groups.filter((g) => g.not).map((g) => cnkiClause(g.field, g.terms));
  let e = pos.join(' AND ');
  for (const n of neg) e += ` NOT ${n}`;
  return addCnkiYears(e, years);
}
export function addCnkiYears(expr, years) {
  if (!years || (!years.from && !years.to)) return expr;
  const from = years.from || 1900;
  const to = years.to || new Date().getFullYear();
  const base = /\bOR\b|\bNOT\b/.test(expr) ? `(${expr})` : expr;
  return `${base} AND YE BETWEEN ('${from}','${to}')`;
}
export function compileWanfang(groups, years, core, exact = true) {
  const pos = groups.filter((g) => !g.not).map((g) => wfClause(g.field, g.terms, exact));
  const neg = groups.filter((g) => g.not).map((g) => wfClause(g.field, g.terms, exact));
  let e = pos.join(' and ');
  for (const n of neg) e += ` not ${n}`;
  return addWfFilters(e, years, core);
}
export function addWfFilters(expr, years, core) {
  let e = expr;
  const needWrap = /\bor\b|\bnot\b/i.test(e);
  const extras = [];
  if (core && core.length) {
    const vals = uniq(core.map((c) => WF_CORE[c]).filter(Boolean));
    if (vals.length === 1) extras.push(`核心收录:(${vals[0]})`);
    else if (vals.length > 1) extras.push(`核心收录:(${vals.join(' or ')})`);
  }
  if (years && (years.from || years.to)) extras.push(`Date:${years.from || 1900}-${years.to || new Date().getFullYear()}`);
  if (!extras.length) return e;
  if (needWrap) e = `(${e})`;
  return [e, ...extras].join(' and ');
}

// ---------------------------------------------------------------------------
// CNKI normalisation
// ---------------------------------------------------------------------------
export function cnkiType(dbname = '', dbType = '') {
  const d = String(dbname).toUpperCase();
  if (/^(CJFQ|CAPJ|CJFD|CJFN|CJTL|ZHYX|SJ)/.test(d) || dbType === '期刊') return 'journal';
  if (/^(CDFD|CMFD|CDMD)/.test(d) || /硕士|博士/.test(dbType)) return 'thesis';
  if (/^(CPFD|IPFD|CPVD)/.test(d) || /会议/.test(dbType)) return 'conference';
  if (/^CCND/.test(d) || /报纸/.test(dbType)) return 'newspaper';
  if (/^(SCSF|SCHF|SCSD|SNAD)/.test(d) || /标准/.test(dbType)) return 'standard';
  if (/^SNAD|成果/.test(d + dbType)) return 'achievement';
  if (/^CCJD/.test(d) || /辑刊/.test(dbType)) return 'series';
  if (/^(WBFD|CBBD)/.test(d) || /图书/.test(dbType)) return 'book';
  return 'other';
}

export const CNKI_PRODUCT_LABEL = {
  CJFQ: '学术期刊', CAPJ: '网络首发', CJFN: '特色期刊', CJTL: '期刊(外文)', ZHYX: '中华医学会期刊',
  CDFD: '博士', CMFD: '硕士', CPFD: '国内会议', IPFD: '国际会议', CCND: '报纸', CCJD: '学术辑刊',
  SCSF: '国家标准', SCHF: '行业标准', SCSD: '标准题录', SNAD: '成果', WBFD: '图书', CCVD: '视频',
};

export function cnkiRecordFromRow(row) {
  const type = cnkiType(row.dbname, row.dbType);
  const date = String(row.date || '').slice(0, 10);
  const key = `cnki:${row.dbname || 'X'}:${row.filename || shortHash(row.url || row.title)}`;
  return {
    key, db: 'CNKI', type,
    type_label: row.dbType || TYPE_LABEL[type] || '',
    title: stripTags(row.title),
    authors: uniq(row.authors),
    source: stripTags(row.source),
    year: date.slice(0, 4), date,
    cited: row.cited || 0, downloads: row.downloads || 0,
    url: row.url || '',
    dbname: row.dbname || '', filename: row.filename || '',
    _exportId: row.exportId || '',
  };
}

const splitBr = (s) => String(s || '').split(/<br\s*\/?>/i).map((x) => x.replace(/&nbsp;/g, ' ').trim()).filter(Boolean);
const splitList = (s) => uniq(String(s || '').split(/[;；]/));

export function parseEndNote(s) {
  const o = { authors: [] };
  for (const line of splitBr(s)) {
    const m = line.match(/^%(\S)\s?(.*)$/);
    if (!m) continue;
    const k = m[1];
    const v = stripTags(m[2]);
    switch (k) {
      case '0': o.refType = v; break;
      case 'A': o.authors.push(v); break;
      case '+': o.affiliations = splitList(v); break;
      case 'T': o.title = v; break;
      case 'J': o.journal = v; break;
      case 'D': o.year = v; break;
      case 'V': o.volume = v; break;
      case 'N': o.issue = v; break;
      case 'K': o.keywords = splitList(v); break;
      case 'X': o.abstract = v; break;
      case 'P': o.pages = v; break;
      case '@': o.issn = v; break;
      case 'L': o.cn = v; break;
      case 'U': o.url = v; break;
      case 'R': o.doi = v; break;
      case 'I': o.publisher = v; break;
      case '9': o.degree = v; break;
      case 'Y': o.supervisor = splitList(v); break;
      case 'B': o.secondary = v; break;
      case 'C': o.place = v; break;
      default: (o.extra = o.extra || {})[k] = v;
    }
  }
  return o;
}

export function parseELearning(s) {
  const o = {};
  for (const line of splitBr(s)) {
    const m = line.match(/^([A-Za-z]+)-[^:：]*[:：]\s?(.*)$/);
    if (m) o[m[1]] = stripTags(m[2]);
  }
  return o;
}

export const cleanGB = (s) => stripTags(String(s || '').replace(/<br\s*\/?>/gi, ' ')).replace(/^\[\d+\]\s*/, '').trim();

export function mergeCnkiExport(rec, en, el, gb) {
  if (en) {
    if (en.authors && en.authors.length) rec.authors = uniq(en.authors);
    if (en.affiliations) rec.affiliations = en.affiliations;
    if (en.keywords) rec.keywords = en.keywords;
    if (en.abstract) rec.abstract = en.abstract;
    for (const f of ['volume', 'issue', 'pages', 'issn', 'cn']) if (en[f]) rec[f] = en[f];
    if (en.doi) rec.doi = en.doi;
    if (en.journal && rec.type === 'journal') rec.source = en.journal;
    if (en.publisher && rec.type === 'thesis' && !rec.source) rec.source = en.publisher;
    if (en.degree) rec.degree = en.degree;
    if (en.supervisor && en.supervisor.length) rec.supervisor = en.supervisor;
    if (en.url && /link\.cnki\.net/.test(en.url)) rec.url_stable = en.url;
  }
  if (el) {
    if (el.Summary && (!rec.abstract || el.Summary.length > rec.abstract.length)) rec.abstract = el.Summary;
    if (el.Teacher) rec.supervisor = splitList(el.Teacher);
    if (el.Degree) rec.degree = el.Degree;
    if (el.Organ && !rec.affiliations) rec.affiliations = splitList(el.Organ);
    if (el.PubTime) rec.date = el.PubTime.slice(0, 10);
    if (el.Year && !rec.year) rec.year = el.Year;
    if (el.Fund) rec.funds = splitList(el.Fund);
    if (el.CLC) rec.clc = splitList(el.CLC);
    if (el.DOI) rec.doi = el.DOI;
    if (el.Link && /link\.cnki\.net/.test(el.Link) && !rec.url_stable) rec.url_stable = el.Link;
    if (el.Keyword && !rec.keywords) rec.keywords = splitList(el.Keyword);
  }
  if (gb) {
    rec.gbt7714 = cleanGB(gb);
    if (!rec.doi) { const m = rec.gbt7714.match(/DOI[:：]\s*(10\.[^\s,，]+?)\.?$/i); if (m) rec.doi = m[1]; }
  }
  if (rec.abstract) rec.abstract_truncated = /(\.\.\.|…)$/.test(rec.abstract);
  return rec;
}

export function mergeCnkiDetail(rec, d) {
  if (!d || d.error) return rec;
  if (d.abstract && (!rec.abstract || rec.abstract_truncated || d.abstract.length > rec.abstract.length)) {
    rec.abstract = d.abstract.replace(/\s*更多\s*还原.*$/, '').replace(/AbstractFilter\(.*$/, '').trim();
    rec.abstract_truncated = false;
  }
  if (d.keywords && d.keywords.length) rec.keywords = uniq(d.keywords);
  if (d.orgs && d.orgs.length && !rec.affiliations) rec.affiliations = d.orgs;
  const f = d.fields || {};
  if (f['基金资助']) rec.funds = uniq(f['基金资助'].split(/[；;]/));
  if (f.DOI) rec.doi = f.DOI.split(/\s/)[0];
  if (f['分类号']) rec.clc = uniq(f['分类号'].split(/[;；\s]/));
  if (f['专题']) rec.cnki_subject = f['专题'];
  if (f['专辑']) rec.cnki_album = f['专辑'];
  if (f['导师'] && !rec.supervisor) rec.supervisor = uniq(f['导师'].split(/[;；,，\s]/));
  if (f['学科专业']) rec.major = f['学科专业'];
  if (d.topTip && rec.type === 'journal') {
    const m = d.topTip.match(/(\d{4})\s*,\s*(\d+)\s*\((\w+)\)\s*:\s*([\d+\-–,]+)/);
    if (m) { rec.volume = rec.volume || m[2]; rec.issue = rec.issue || m[3]; rec.pages = rec.pages || m[4]; }
  }
  rec.deep = true;
  return rec;
}

// ---------------------------------------------------------------------------
// Wanfang normalisation
// ---------------------------------------------------------------------------
const WF_KIND = { Periodical: 'journal', Thesis: 'thesis', Conference: 'conference', Patent: 'patent', Standard: 'standard', Cstad: 'achievement', Claw: 'law', Nstr: 'report' };
export function wfRecord(type, o, { detail = false } = {}) {
  const kind = WF_KIND[type] || 'other';
  const titles = (o.titleList || []).map(stripTags);
  const year = String(o.publishyear || (o.publishdate || '').slice(0, 4) || o.meetingyear || '');
  const rec = {
    key: `wanfang:${type}:${o.id}`, db: 'Wanfang', type: kind,
    type_label: kind === 'thesis' ? (o.degree ? `${o.degree}学位论文` : '学位论文') : (TYPE_LABEL[kind] || type),
    wf_type: type, id: o.id,
    title: titles[0] || '', title_en: titles[1] || '',
    authors: uniq((o.creatorList || []).map(stripTags)),
    affiliations: uniq((o.originalorganizationList || o.firstorganizationList || []).map(stripTags)),
    year, date: String(o.publishdate || '').slice(0, 10),
    keywords: uniq((o.keywordsList || []).map(stripTags)),
    cited: o.citedcount || 0, downloads: o.downloadcount || 0,
    url: `https://d.wanfangdata.com.cn/${type.toLowerCase()}/${o.id}`,
  };
  if (kind === 'journal') rec.source = stripTags((o.periodicaltitleList || [])[0] || '');
  else if (kind === 'thesis') rec.source = stripTags((o.organizationnormList || o.originalorganizationList || [])[0] || '');
  else if (kind === 'conference') rec.source = stripTags((o.meetingtitleList || [])[0] || '');
  if (o.volum) rec.volume = String(o.volum);
  if (o.issue) rec.issue = String(o.issue);
  if (o.page) rec.pages = String(o.page);
  if (o.doi) rec.doi = o.doi;
  if (o.issn) rec.issn = o.issn;
  if (o.cn) rec.cn = o.cn;
  if (o.coreperiodicalList && o.coreperiodicalList.length) rec.core = uniq(o.coreperiodicalList.map((c) => WF_CORE_LABEL[c] || c));
  if (o.fundList && o.fundList.length) {
    rec.funds = uniq(o.fundList.map((f) => {
      const i = f.indexOf(':');
      const no = i >= 0 ? f.slice(0, i).trim() : '';
      const name = i >= 0 ? f.slice(i + 1).trim() : f.trim();
      return no ? `${name}（${no}）` : name;
    }));
  }
  const clc = o.originalclasscodeList || o.classcodeList;
  if (clc && clc.length) rec.clc = uniq(clc);
  if (o.degree) rec.degree = o.degree;
  if (o.tutorList && o.tutorList.length) rec.supervisor = uniq(o.tutorList);
  if (o.major) rec.major = o.major;
  if (o.meetingdate) rec.meeting_date = o.meetingdate;
  if (o.meetingarea) rec.meeting_place = o.meetingarea;
  if (detail && o.abstractList && o.abstractList.length) {
    rec.abstract = stripTags(o.abstractList[0]);
    if (o.abstractList[1]) rec.abstract_en = stripTags(o.abstractList[1]);
  }
  if (detail) rec.deep = true;
  return rec;
}

// ---------------------------------------------------------------------------
// De-duplication
// ---------------------------------------------------------------------------
export const normTitle = (t) => String(t || '').normalize('NFKC').toLowerCase().replace(/<[^>]+>/g, '').replace(/[\s\p{P}\p{S}]/gu, '');
const firstAuthor = (r) => normTitle((r.authors || [])[0] || '');

export function mergeInto(a, b) {
  for (const [k, v] of Object.entries(b)) {
    if (k === 'key' || k === 'db' || k.startsWith('_')) continue;
    const cur = a[k];
    const empty = cur === undefined || cur === null || cur === '' || (Array.isArray(cur) && !cur.length);
    if (empty && v !== undefined && v !== null && v !== '' && !(Array.isArray(v) && !v.length)) a[k] = v;
    else if (k === 'abstract' && v && a.abstract_truncated && v.length > String(cur).length) { a.abstract = v; a.abstract_truncated = false; }
    else if (k === 'core' && Array.isArray(v)) a.core = uniq([...(cur || []), ...v]);
  }
  a.also_in = uniq([...(a.also_in || []), b.db, ...(b.also_in || [])].filter((d) => d !== a.db));
  a.dup_keys = uniq([...(a.dup_keys || []), b.key, ...(b.dup_keys || [])]);
  if ((b.cited || 0) > (a.cited || 0)) a.cited_max = b.cited;
  return a;
}

export function dedupe(records) {
  const out = [];
  const byDoi = new Map();
  const byTitle = new Map();
  let merged = 0;
  for (const r0 of records) {
    const r = { ...r0 };
    const doi = String(r.doi || '').toLowerCase().trim();
    const nt = normTitle(r.title);
    const tkey = nt + '|' + (r.type === 'thesis' ? 'thesis' : 'other');
    let hit = doi ? byDoi.get(doi) : null;
    if (!hit && nt.length >= 6) {
      const cands = byTitle.get(tkey) || [];
      hit = cands.find((c) => {
        const fa = firstAuthor(c), fb = firstAuthor(r);
        const yOk = !c.year || !r.year || Math.abs(+c.year - +r.year) <= 1;
        const aOk = !fa || !fb || fa === fb;
        return yOk && aOk;
      });
    }
    if (hit) { mergeInto(hit, r); merged++; continue; }
    out.push(r);
    if (doi) byDoi.set(doi, r);
    if (nt) { const l = byTitle.get(tkey) || []; l.push(r); byTitle.set(tkey, l); }
  }
  return { records: out, merged };
}

// ---------------------------------------------------------------------------
// Export formats
// ---------------------------------------------------------------------------
const gbAuthors = (a) => {
  a = uniq(a);
  if (!a.length) return '佚名';
  return a.length > 3 ? a.slice(0, 3).join(',') + ',等' : a.join(',');
};
export function toGB(r) {
  if (r.gbt7714) return r.gbt7714;
  const au = gbAuthors(r.authors);
  const yr = r.year || '';
  switch (r.type) {
    case 'journal': {
      let s = `${au}.${r.title}[J].${r.source || ''},${yr}`;
      if (r.volume) s += `,${r.volume}`;
      if (r.issue) s += `(${r.issue})`;
      if (r.pages) s += `:${r.pages}`;
      s += '.';
      if (r.doi) s += `DOI:${r.doi}.`;
      return s;
    }
    case 'thesis': return `${au}.${r.title}[D].${r.source || ''},${yr}.` + (r.doi ? `DOI:${r.doi}.` : '');
    case 'conference': return `${au}.${r.title}[C]//${r.source || ''}.${yr}` + (r.pages ? `:${r.pages}` : '') + '.';
    case 'newspaper': return `${au}.${r.title}[N].${r.source || ''},${r.date || yr}.`;
    case 'standard': return `${r.title}[S].${yr}.`;
    case 'patent': return `${au}.${r.title}[P].${yr}.`;
    default: return `${au}.${r.title}[Z].${r.source ? r.source + ',' : ''}${yr}.`;
  }
}

const RIS_TY = { journal: 'JOUR', thesis: 'THES', conference: 'CPAPER', newspaper: 'NEWS', book: 'BOOK', patent: 'PAT', standard: 'STAND', series: 'JOUR', special_journal: 'JOUR' };
export function toRIS(list) {
  const L = [];
  for (const r of list) {
    const add = (k, v) => { if (v !== undefined && v !== null && String(v).trim() !== '') L.push(`${k}  - ${String(v).replace(/\r?\n/g, ' ').trim()}`); };
    add('TY', RIS_TY[r.type] || 'GEN');
    add('TI', r.title);
    if (r.title_en) add('TT', r.title_en);
    for (const a of r.authors || []) add('AU', a);
    if (r.type === 'journal') { add('T2', r.source); add('JO', r.source); }
    else if (r.type === 'thesis') { add('PB', r.source); add('M3', r.degree || r.type_label); for (const s of r.supervisor || []) add('A3', s); }
    else if (r.type === 'conference') add('T2', r.source);
    else add('T2', r.source);
    add('PY', r.year);
    if (r.date) add('DA', r.date.replace(/-/g, '/'));
    add('VL', r.volume);
    add('IS', r.issue);
    if (r.pages) {
      const [sp, ep] = String(r.pages).split(/[-–]/);
      add('SP', sp); if (ep) add('EP', ep);
    }
    add('AB', r.abstract);
    for (const k of r.keywords || []) add('KW', k);
    add('DO', r.doi);
    add('SN', r.issn);
    add('UR', r.url_stable || r.url);
    for (const a of r.affiliations || []) add('AD', a);
    add('LA', 'zh');
    add('DB', [r.db, ...(r.also_in || [])].join(' / '));
    const notes = [];
    if (r.core && r.core.length) notes.push('收录: ' + r.core.join(', '));
    if (r.cited) notes.push('被引: ' + r.cited);
    if (r.funds && r.funds.length) notes.push('基金: ' + r.funds.join('; '));
    if (r.clc && r.clc.length) notes.push('分类号: ' + r.clc.join('; '));
    if (r.grade) notes.push('相关性分级: ' + r.grade);
    if (notes.length) add('N1', notes.join(' | '));
    L.push('ER  - ', '');
  }
  return L.join('\r\n');
}

const bibEsc = (s) => String(s || '').replace(/([{}])/g, '\\$1').replace(/\r?\n/g, ' ');
export function toBib(list) {
  const used = new Set();
  return list.map((r) => {
    let base = `${(r.db || 'cn').toLowerCase()}${r.year || ''}_${shortHash(r.key || r.title).slice(0, 6)}`;
    while (used.has(base)) base += 'a';
    used.add(base);
    const t = r.type === 'journal' ? 'article' : r.type === 'thesis' ? (/博士/.test(r.degree || r.type_label || '') ? 'phdthesis' : 'mastersthesis') : r.type === 'conference' ? 'inproceedings' : 'misc';
    const f = [];
    const add = (k, v) => { if (v !== undefined && v !== null && String(v).trim() !== '') f.push(`  ${k} = {${bibEsc(v)}}`); };
    add('title', r.title);
    add('author', (r.authors || []).join(' and '));
    if (t === 'article') add('journal', r.source);
    if (/thesis/.test(t)) add('school', r.source);
    if (t === 'inproceedings') add('booktitle', r.source);
    if (t === 'misc' && r.source) add('howpublished', r.source);
    add('year', r.year); add('volume', r.volume); add('number', r.issue);
    add('pages', r.pages ? String(r.pages).replace(/-/, '--') : '');
    add('doi', r.doi); add('issn', r.issn); add('url', r.url_stable || r.url);
    add('keywords', (r.keywords || []).join(', ')); add('abstract', r.abstract);
    add('language', 'chinese'); add('note', [r.db, ...(r.also_in || [])].join('/') + (r.core && r.core.length ? '; ' + r.core.join(',') : ''));
    return `@${t}{${base},\n${f.join(',\n')}\n}`;
  }).join('\n\n') + '\n';
}

const csvCell = (v) => {
  const s = Array.isArray(v) ? v.join('; ') : (v === undefined || v === null ? '' : String(v));
  return /[",\r\n]/.test(s) ? `"${s.replace(/"/g, '""')}"` : s;
};
export function toCSV(list) {
  const cols = [
    ['序号', (r, i) => i + 1], ['数据库', (r) => [r.db, ...(r.also_in || [])].join('/')], ['文献类型', (r) => r.type_label || TYPE_LABEL[r.type]],
    ['题名', (r) => r.title], ['作者', (r) => r.authors], ['机构', (r) => r.affiliations], ['来源', (r) => r.source],
    ['年', (r) => r.year], ['卷', (r) => r.volume], ['期', (r) => r.issue], ['页码', (r) => r.pages], ['DOI', (r) => r.doi],
    ['核心收录', (r) => r.core], ['被引', (r) => r.cited], ['下载', (r) => r.downloads], ['关键词', (r) => r.keywords],
    ['摘要', (r) => r.abstract], ['基金', (r) => r.funds], ['分类号', (r) => r.clc], ['学位/导师', (r) => [r.degree, ...(r.supervisor || [])].filter(Boolean)],
    ['相关性分级', (r) => r.grade], ['分级理由', (r) => r.grade_reason], ['GB/T 7714', (r) => toGB(r)], ['链接', (r) => r.url_stable || r.url], ['记录键', (r) => r.key],
  ];
  const lines = [cols.map((c) => c[0]).join(',')];
  list.forEach((r, i) => lines.push(cols.map((c) => csvCell(c[1](r, i))).join(',')));
  return '﻿' + lines.join('\r\n') + '\r\n';
}

export function toGBText(list) {
  return list.map((r, i) => `[${i + 1}] ${toGB(r)}`).join('\r\n') + '\r\n';
}

export function toMarkdown(list, title) {
  const L = [`# ${title || '文献清单'}`, '', `共 ${list.length} 篇。`, ''];
  list.forEach((r, i) => {
    const meta = [r.type_label || TYPE_LABEL[r.type], (r.core || []).join('/'), r.cited ? `被引 ${r.cited}` : '', [r.db, ...(r.also_in || [])].join('+')].filter(Boolean).join(' · ');
    L.push(`${i + 1}. ${toGB(r)}  `);
    L.push(`   ${meta}${r.grade ? ` · 分级 ${r.grade}` : ''} · [链接](${r.url_stable || r.url})`);
    if (r.abstract) L.push(`   > ${r.abstract.slice(0, 400)}${r.abstract.length > 400 ? '…' : ''}`);
    L.push('');
  });
  return L.join('\n');
}
